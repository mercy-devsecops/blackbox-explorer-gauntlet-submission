"""Local tools schema and dispatcher for BlackBox Explorer.

Exposes deterministic computation and forensics as local schema-validated tools
to the LLM during the ReAct loop without confounding official MCP tool coverage.
"""

from __future__ import annotations

from typing import Any
from blackbox.computation import ComputationEngine
from blackbox.forensics import ForensicsEngine

LOCAL_TOOL_DEFINITIONS = [
    {
        "name": "local_math_eval",
        "description": (
            "Deterministically evaluate safe mathematical expressions (arithmetic, exponents, "
            "sqrt, gcd, lcm, abs, min, max). Example: '123 * 456 + (789 // 3)' or 'gcd(240, 360)'."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": "Safe math expression to evaluate",
                }
            },
            "required": ["expression"],
        },
    },
    {
        "name": "local_modular_math",
        "description": "Perform exact modular arithmetic: 'mod' (a % m), 'pow_mod' (base^exp % m), or 'inverse_mod'.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "operation": {"type": "string", "enum": ["mod", "pow_mod", "inverse_mod"]},
                "base": {"type": "integer"},
                "modulus": {"type": "integer"},
                "exponent": {"type": "integer", "description": "Required for pow_mod"},
            },
            "required": ["operation", "base", "modulus"],
        },
    },
    {
        "name": "local_combinatorics",
        "description": "Calculate exact factorials, combinations (n choose k), or permutations.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "operation": {"type": "string", "enum": ["factorial", "combinations", "permutations"]},
                "n": {"type": "integer"},
                "k": {"type": "integer", "description": "Subset size for combinations/permutations"},
            },
            "required": ["operation", "n"],
        },
    },
    {
        "name": "local_decode_artifact",
        "description": "Decode an encoded string (base64, hex, url, rot13, zlib) or auto-peel multi-layer encodings.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "enum": ["base64", "hex", "url", "rot13", "zlib", "auto_peel"],
                    "description": "Encoding format, or 'auto_peel' for recursive multi-layer deobfuscation",
                },
                "payload": {"type": "string", "description": "The encoded string"},
            },
            "required": ["operation", "payload"],
        },
    },
    {
        "name": "local_compute_hash",
        "description": "Compute cryptographic checksum/hash of a string (md5, sha1, sha256, sha512, crc32).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "algorithm": {"type": "string", "enum": ["md5", "sha1", "sha256", "sha512", "crc32"]},
                "data": {"type": "string"},
            },
            "required": ["algorithm", "data"],
        },
    },
    {
        "name": "local_inspect_signature",
        "description": "Identify file signature (magic bytes, mime type) from raw hex or byte headers.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "header_hex_or_bytes": {"type": "string", "description": "Hex bytes or header characters"},
            },
            "required": ["header_hex_or_bytes"],
        },
    },

    {
        "name": "local_analyze_network_or_code",
        "description": "Analyze network/access logs for attacks or audit source code for security vulnerabilities.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "target_type": {"type": "string", "enum": ["network_log", "source_code"]},
                "payload": {"type": "string"},
            },
            "required": ["target_type", "payload"],
        },
    },
    {
        "name": "local_parse_pcap",
        "description": "Parse PCAP packet data (hex or raw) into global header metadata and packet IP/TCP/UDP records.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "pcap_hex": {"type": "string", "description": "Hex-encoded PCAP file bytes"},
            },
            "required": ["pcap_hex"],
        },
    },
]


def is_local_tool(name: str) -> bool:
    """Check if tool is an internal local capability rather than an official MCP tool."""
    return str(name or "").startswith("local_")


def execute_local_tool(name: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Execute local deterministic utility function."""
    clean_name = str(name).strip()

    if clean_name == "local_math_eval":
        return ComputationEngine.evaluate_expression(arguments.get("expression", ""))

    elif clean_name == "local_modular_math":
        return ComputationEngine.modular_arithmetic(
            operation=arguments.get("operation", ""),
            base=int(arguments.get("base", 0)),
            modulus=int(arguments.get("modulus", 1)),
            exponent=int(arguments["exponent"]) if "exponent" in arguments else None,
        )

    elif clean_name == "local_combinatorics":
        return ComputationEngine.combinatorics(
            operation=arguments.get("operation", ""),
            n=int(arguments.get("n", 0)),
            k=int(arguments["k"]) if "k" in arguments else None,
        )

    elif clean_name == "local_decode_artifact":
        op = str(arguments.get("operation", "")).strip().lower()
        payload = str(arguments.get("payload", ""))
        if op == "auto_peel":
            return ForensicsEngine.multi_layer_deobfuscate(payload)
        return ForensicsEngine.decode_single(op, payload)

    elif clean_name == "local_compute_hash":
        return ForensicsEngine.compute_hash(
            algorithm=arguments.get("algorithm", "sha256"),
            data=arguments.get("data", ""),
        )

    elif clean_name == "local_inspect_signature":
        return ForensicsEngine.identify_magic_bytes(arguments.get("header_hex_or_bytes", ""))

    elif clean_name == "local_solve_order_constraints":
        return ComputationEngine.solve_linear_order_constraints(
            items=arguments.get("items", []),
            constraints=arguments.get("constraints", []),
        )

    elif clean_name == "local_analyze_network_or_code":
        target = str(arguments.get("target_type", "")).strip().lower()
        payload = str(arguments.get("payload", ""))
        if target == "source_code":
            return ForensicsEngine.audit_code_vulnerabilities(payload)
        return ForensicsEngine.analyze_network_log_or_pcap_header(payload)

    elif clean_name == "local_parse_pcap":
        return ForensicsEngine.parse_pcap_structure(arguments.get("pcap_hex", ""))

    return {"error": f"Unknown local tool: {clean_name}"}
