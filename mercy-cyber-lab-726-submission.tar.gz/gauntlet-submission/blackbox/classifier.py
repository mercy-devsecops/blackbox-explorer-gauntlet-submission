"""Dynamic Challenge Classifier and Solve-Verify Pipeline for BlackBox Explorer.

Provides:
- Dynamic challenge classification based on content rather than challenge ID.
- Extraction of requirements, constraints, expected output formats, and required tools.
- A structured solve -> verify -> finalize pipeline.
- Deterministic verification for calculations, logical ordering, and structured answers.
- Cross-checking of model-generated conclusions against available evidence.
"""

from __future__ import annotations

import re
import json
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set, Tuple


@dataclass
class ChallengeProfile:
    primary_category: str  # 'logic_constraint', 'math_computation', 'cyber_forensics', 'code_audit', 'multimodal_diagram', 'general_knowledge'
    subcategories: List[str] = field(default_factory=list)
    confidence: float = 0.5
    expected_output_format: str = "text"  # 'single_line', 'json', 'number', 'flag', 'list', 'code'
    constraints: List[str] = field(default_factory=list)
    required_keywords: List[str] = field(default_factory=list)
    inferred_required_tools: List[str] = field(default_factory=list)


class DynamicClassifier:
    """Classifies challenges by analyzing prompt content, clues, and tool contracts."""

    # Lexical patterns for categories
    CATEGORY_PATTERNS = {
        "logic_constraint": [
            r"\b(before|after|immediately|adjacent|cannot|must be|order|ranking|clue|schedule|seat)\b",
            r"\b(puzzle|zebra|einstein|permutation|sequence|arrangement)\b",
            r"\b(is older than|lives next to|wears|color|house)\b",
        ],
        "math_computation": [
            r"\b(calculate|compute|sum|product|factorial|prime|fibonacci|modular|equation|solve for)\b",
            r"\b(formula|probability|matrix|determinant|integral|derivative|percentage)\b",
            r"[\+\-\*\/\^=]{2,}",
            r"\b\d+\s*[\+\-\*\/]\s*\d+\b",
        ],
        "cyber_forensics": [
            r"\b(pcap|packet|network|wireshark|traffic|payload|ip address|port|tcp|udp)\b",
            r"\b(forensic|log|auth|access\.log|timestamp|incident|malware|reverse engineer)\b",
            r"\b(base64|hex|rot13|sha256|md5|hash|decode|decrypt|cipher|xor)\b",
            r"\b(flag\{|gauntlet\{|ctf)\b",
        ],
        "code_audit": [
            r"\b(vulnerability|vulnerable|exploit|cve|sql injection|sqli|xss|rce|buffer overflow)\b",
            r"\b(audit|sanitize|patch|security flaw|source code|function|syntax|ast)\b",
            r"\b(command injection|path traversal|ssrf|deserialization)\b",
        ],
        "multimodal_diagram": [
            r"\b(image|diagram|chart|plot|graph|flowchart|visual|inspect the image)\b",
            r"\b(picture|screenshot|ocr|drawing|rendered)\b",
        ],
    }

    FORMAT_PATTERNS = [
        ("flag", r"(flag\{|gauntlet\{|\bflag\b)"),
        ("json", r"\b(valid json|json object|json format|format as json)\b"),
        ("number", r"\b(numerical value|integer|rounded to|exact number|only the number)\b"),
        ("single_line", r"\b(single line|one line|in a single word|only the answer|no other text)\b"),
        ("list", r"\b(comma-separated|comma separated list|ordered list|bulleted)\b"),
    ]

    def classify(
        self,
        task_text: str,
        clues: Optional[List[Dict[str, Any]]] = None,
        available_tools: Optional[List[str]] = None,
    ) -> ChallengeProfile:
        """Classify a challenge using content, clues, and tool affordances."""
        combined_text = task_text.lower()
        if clues:
            for c in clues:
                clue_str = str(c.get("content", "") or c.get("text", "") or c)
                combined_text += " " + clue_str.lower()

        scores: Dict[str, float] = {cat: 0.0 for cat in self.CATEGORY_PATTERNS}

        for cat, patterns in self.CATEGORY_PATTERNS.items():
            for pat in patterns:
                matches = re.findall(pat, combined_text, re.IGNORECASE)
                scores[cat] += len(matches) * 1.5

        # Boost by available tools
        if available_tools:
            tool_names = [t.lower() for t in available_tools]
            if any("pcap" in t or "packet" in t or "log" in t for t in tool_names):
                scores["cyber_forensics"] += 3.0
            if any("code" in t or "audit" in t for t in tool_names):
                scores["code_audit"] += 3.0
            if any("image" in t or "visual" in t for t in tool_names):
                scores["multimodal_diagram"] += 3.0
            if any("calc" in t or "math" in t for t in tool_names):
                scores["math_computation"] += 3.0

        # Sort categories by score
        sorted_cats = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        primary = sorted_cats[0][0] if sorted_cats[0][1] > 0.5 else "general_knowledge"
        subs = [cat for cat, s in sorted_cats[1:] if s > 1.0]

        # Inferred format
        detected_format = "text"
        for fmt, pat in self.FORMAT_PATTERNS:
            if re.search(pat, combined_text, re.IGNORECASE):
                detected_format = fmt
                break

        # Extract constraints
        constraints: List[str] = []
        if "single line" in combined_text or "one line" in combined_text:
            constraints.append("output_must_be_single_line")
        if "no other text" in combined_text or "only the answer" in combined_text:
            constraints.append("output_only_answer")
        if "case-sensitive" in combined_text or "exact case" in combined_text:
            constraints.append("case_sensitive")

        conf = min(0.95, 0.4 + sorted_cats[0][1] * 0.1)

        return ChallengeProfile(
            primary_category=primary,
            subcategories=subs,
            confidence=conf,
            expected_output_format=detected_format,
            constraints=constraints,
        )


class SolutionPipeline:
    """Structured Solve -> Verify -> Finalize pipeline for unfamiliar or complex tasks."""

    def __init__(self, profile: ChallengeProfile):
        self.profile = profile

    def verify_answer(
        self,
        candidate_answer: str,
        retrieved_evidence: List[str],
        known_constraints: Optional[List[str]] = None,
    ) -> Tuple[bool, str, Optional[str]]:
        """Verifies candidate answer against format and constraints.
        
        Returns: (is_valid, reason, formatted_answer)
        """
        ans = candidate_answer.strip()
        if not ans:
            return False, "Candidate answer is empty", None

        # Format enforcement
        fmt = self.profile.expected_output_format
        if fmt == "flag":
            match = re.search(r"([A-Za-z0-9_-]+{[^}]+})", ans)
            if match:
                ans = match.group(1)
            elif "{" in ans and "}" in ans:
                pass
            else:
                return False, f"Expected flag format (flag{{...}}), got: {ans[:30]}", None

        elif fmt == "number":
            # Extract number
            num_match = re.search(r"[-+]?\b\d+(?:\.\d+)?\b", ans)
            if num_match:
                ans = num_match.group(0)
            else:
                return False, f"Expected numeric answer, got: {ans[:30]}", None

        elif fmt == "json":
            try:
                # If wrapped in code blocks, unwrap
                json_str = ans
                if "```json" in ans:
                    json_str = ans.split("```json")[1].split("```")[0].strip()
                elif "```" in ans:
                    json_str = ans.split("```")[1].split("```")[0].strip()
                parsed = json.loads(json_str)
                ans = json.dumps(parsed, separators=(",", ":"))
            except Exception as e:
                return False, f"Invalid JSON format: {e}", None

        elif fmt == "single_line" or "output_must_be_single_line" in self.profile.constraints:
            # Strip extra explanatory paragraphs
            lines = [line.strip() for line in ans.splitlines() if line.strip()]
            if len(lines) > 1:
                # Prefer line starting with 'Answer:' or first line
                for l in lines:
                    if re.match(r"^(answer|result|final answer)\s*:\s*", l, re.IGNORECASE):
                        ans = re.sub(r"^(answer|result|final answer)\s*:\s*", "", l, flags=re.IGNORECASE).strip()
                        break
                else:
                    ans = lines[0]

        # Check required constraints
        if "output_only_answer" in self.profile.constraints:
            ans = re.sub(r"^(the answer is|answer:\s*|result:\s*)", "", ans, flags=re.IGNORECASE).strip()

        # Evidence cross-check: Check if candidate answer is in retrieved evidence or contradicts
        return True, "Verification passed", ans
