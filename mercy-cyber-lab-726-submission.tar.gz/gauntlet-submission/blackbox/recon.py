"""Dynamic MCP tool discovery, schema inspection, and function conversion.

Provides:
- Schema conversion from MCP ToolDef to OpenAI function-calling format.
- Schema parameter validation before tool execution.
- Tool categorization and capability detection.
"""

from __future__ import annotations

import re
from typing import Any


class ToolSchemaError(ValueError):
    """Raised when tool arguments violate the declared schema."""


def sanitize_tool_name(name: str) -> str:
    """Ensure tool name is a valid OpenAI function name ([a-zA-Z0-9_-]+)."""
    clean = re.sub(r"[^a-zA-Z0-9_\-]", "_", name)
    return clean[:64]


def mcp_to_openai_tool(tool: Any) -> dict[str, Any]:
    """Convert an MCP ToolDef or dict to an OpenAI tool definition."""
    name = getattr(tool, "name", None) or (tool.get("name") if isinstance(tool, dict) else "")
    description = getattr(tool, "description", None) or (tool.get("description") if isinstance(tool, dict) else "") or ""
    schema = getattr(tool, "inputSchema", None) or (tool.get("inputSchema") if isinstance(tool, dict) else None)
    
    if not isinstance(schema, dict):
        schema = {"type": "object", "properties": {}}
    
    # Ensure properties exists
    if "type" not in schema:
        schema["type"] = "object"
    if "properties" not in schema:
        schema["properties"] = {}
        
    return {
        "type": "function",
        "function": {
            "name": sanitize_tool_name(str(name)),
            "description": str(description)[:1024],
            "parameters": schema,
        }
    }


def validate_tool_arguments(
    tool_name: str,
    arguments: dict[str, Any],
    schema: dict[str, Any],
) -> tuple[bool, str | None]:
    """Validate arguments against schema required fields and basic types.
    
    Returns:
        (is_valid, error_message)
    """
    if not isinstance(arguments, dict):
        return False, f"Tool '{tool_name}' arguments must be a JSON object, got {type(arguments).__name__}."

    required = schema.get("required", [])
    if isinstance(required, list):
        for req_field in required:
            if req_field not in arguments:
                return False, f"Missing required parameter '{req_field}' for tool '{tool_name}'."
            if arguments[req_field] is None:
                return False, f"Parameter '{req_field}' cannot be null for tool '{tool_name}'."

    properties = schema.get("properties", {})
    if isinstance(properties, dict):
        for key, val in arguments.items():
            if key not in properties:
                continue  # Permissive for unexpected extra keys unless additionalProperties=False
            prop_def = properties[key]
            if not isinstance(prop_def, dict):
                continue
            expected_type = prop_def.get("type")
            if expected_type == "string" and not isinstance(val, str):
                return False, f"Field '{key}' must be a string, got {type(val).__name__}."
            elif expected_type == "integer" and (not isinstance(val, int) or isinstance(val, bool)):
                return False, f"Field '{key}' must be an integer, got {type(val).__name__}."
            elif expected_type == "number" and not isinstance(val, (int, float)):
                return False, f"Field '{key}' must be a number, got {type(val).__name__}."
            elif expected_type == "boolean" and not isinstance(val, bool):
                return False, f"Field '{key}' must be a boolean, got {type(val).__name__}."
            elif expected_type == "array" and not isinstance(val, list):
                return False, f"Field '{key}' must be an array, got {type(val).__name__}."
            elif expected_type == "object" and not isinstance(val, dict):
                return False, f"Field '{key}' must be an object, got {type(val).__name__}."

            # Check enum constraint
            enum_vals = prop_def.get("enum")
            if isinstance(enum_vals, list) and val not in enum_vals:
                return False, f"Field '{key}' value '{val}' not in allowed enum: {enum_vals}."

    return True, None


class ReconManager:
    """Manages tool discovery, schema registry, and mapping to sanitized names."""

    def __init__(self, discovered_tools: list[Any]) -> None:
        self.raw_tools = discovered_tools
        self.tool_map: dict[str, Any] = {}
        self.sanitized_to_original: dict[str, str] = {}
        self.original_to_sanitized: dict[str, str] = {}
        self.openai_tools: list[dict[str, Any]] = []

        for tool in discovered_tools:
            orig_name = getattr(tool, "name", None) or (tool.get("name") if isinstance(tool, dict) else "")
            orig_name = str(orig_name).strip()
            if not orig_name:
                continue
            sanitized = sanitize_tool_name(orig_name)
            self.tool_map[orig_name] = tool
            self.sanitized_to_original[sanitized] = orig_name
            self.original_to_sanitized[orig_name] = sanitized
            self.openai_tools.append(mcp_to_openai_tool(tool))

    def get_tool_schema(self, tool_name: str) -> dict[str, Any]:
        """Retrieve schema for a tool name (original or sanitized)."""
        orig_name = self.resolve_tool_name(tool_name)
        tool = self.tool_map.get(orig_name)
        if not tool:
            return {"type": "object", "properties": {}}
        schema = getattr(tool, "inputSchema", None) or (tool.get("inputSchema") if isinstance(tool, dict) else None)
        return schema if isinstance(schema, dict) else {"type": "object", "properties": {}}

    def resolve_tool_name(self, name: str) -> str:
        """Resolve a tool name to its original MCP registered name."""
        clean = name.strip()
        if clean in self.tool_map:
            return clean
        if clean in self.sanitized_to_original:
            return self.sanitized_to_original[clean]
        # Case-insensitive search
        for orig, sanitized in self.original_to_sanitized.items():
            if orig.lower() == clean.lower() or sanitized.lower() == clean.lower():
                return orig
        return clean

    def to_openai_definitions(self) -> list[dict[str, Any]]:
        return list(self.openai_tools)

    def describe_tools_for_prompt(self) -> str:
        """Describe available tools in plain text for structured prompt injection."""
        lines = []
        for orig_name, tool in self.tool_map.items():
            desc = getattr(tool, "description", None) or (tool.get("description") if isinstance(tool, dict) else "") or ""
            schema = self.get_tool_schema(orig_name)
            props = schema.get("properties", {})
            req = schema.get("required", [])
            param_desc = []
            for p_name, p_info in props.items():
                p_type = p_info.get("type", "any") if isinstance(p_info, dict) else "any"
                is_req = " (required)" if p_name in req else " (optional)"
                param_desc.append(f"{p_name}: {p_type}{is_req}")
            params_str = ", ".join(param_desc) if param_desc else "no parameters"
            lines.append(f"- `{orig_name}`: {desc} | Parameters: [{params_str}]")
        return "\n".join(lines)
