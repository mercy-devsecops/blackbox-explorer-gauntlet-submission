"""Lightweight, safe digital forensics and artifact deobfuscation engine.

Provides:
- Base64, Hexadecimal, URL, and ROT13 decoding.
- Hashing and checksums (md5, sha1, sha256, crc32).
- Magic-byte / file-signature identification without external dependencies.
- Timestamp conversion (Unix epoch to ISO UTC).
- Bounded multi-layer decoding with recursion and size guards.
- Decompression bomb protection (max output size limits).
- Evidence transformation history tracking.
"""

from __future__ import annotations

import base64
import binascii
import codecs
import datetime
import hashlib
import re
import urllib.parse
import zlib
from dataclasses import dataclass, field
from typing import Any

MAX_INPUT_BYTES = 500 * 1024       # 500 KB input limit
MAX_DECOMPRESSED_BYTES = 2 * 1024 * 1024  # 2 MB decompression bomb limit
MAX_RECURSION_DEPTH = 6

# Known file signatures (magic bytes)
MAGIC_SIGNATURES: list[tuple[bytes, str, str]] = [
    (b"\x89PNG\r\n\x1a\n", "image/png", "PNG image"),
    (b"\xff\xd8\xff", "image/jpeg", "JPEG image"),
    (b"GIF87a", "image/gif", "GIF image (87a)"),
    (b"GIF89a", "image/gif", "GIF image (89a)"),
    (b"PK\x03\x04", "application/zip", "ZIP archive"),
    (b"\x1f\x8b\x08", "application/gzip", "GZIP compressed archive"),
    (b"\x7fELF", "application/x-executable", "ELF Linux binary"),
    (b"MZ", "application/x-dosexec", "DOS/PE Windows executable"),
    (b"%PDF-", "application/pdf", "PDF document"),
    (b"\xd4\xc3\xb2\xa1", "application/vnd.tcpdump.pcap", "PCAP capture (microsecond)"),
    (b"\xa1\xb2\xc3\xd4", "application/vnd.tcpdump.pcap", "PCAP capture (swapped)"),
    (b"\x0a\x0d\x0d\x0a", "application/vnd.tcpdump.pcapng", "PCAPNG capture"),
    (b"BZh", "application/x-bzip2", "BZIP2 compressed archive"),
    (b"\xfd7zXZ\x00", "application/x-xz", "XZ compressed archive"),
    (b"7z\xbc\xaf\x27\x1c", "application/x-7z-compressed", "7-Zip archive"),
]


@dataclass
class TransformationStep:
    layer: int
    operation: str
    output_preview: str
    length: int


class ForensicsEngine:
    """Artifact analysis, decoding, and forensics suite."""

    @classmethod
    def identify_magic_bytes(cls, data: bytes | str) -> dict[str, Any]:
        """Identify file signature and mime type from header bytes."""
        if isinstance(data, str):
            # Check if hex encoded string
            clean = data.strip().replace(" ", "").replace("0x", "")
            try:
                raw_bytes = bytes.fromhex(clean)
            except Exception:
                raw_bytes = data.encode("utf-8", errors="replace")
        else:
            raw_bytes = data

        for magic, mime, desc in MAGIC_SIGNATURES:
            if raw_bytes.startswith(magic):
                return {
                    "matched": True,
                    "mime_type": mime,
                    "description": desc,
                    "magic_hex": magic.hex(),
                }

        return {
            "matched": False,
            "mime_type": "application/octet-stream",
            "description": "Unknown binary or text data",
            "magic_hex": raw_bytes[:8].hex(),
        }

    @classmethod
    def decode_single(cls, operation: str, payload: str) -> dict[str, Any]:
        """Perform a single decoding operation: base64, hex, url, rot13, zlib."""
        text = str(payload or "").strip()
        if len(text.encode("utf-8")) > MAX_INPUT_BYTES:
            return {"error": f"Input size exceeds safe limit ({MAX_INPUT_BYTES} bytes)"}

        op = operation.strip().lower()
        try:
            if op == "base64":
                # Add missing padding if needed
                pad = len(text) % 4
                if pad:
                    text += "=" * (4 - pad)
                raw = base64.b64decode(text, validate=False)
                # Check magic bytes of decoded payload
                magic = cls.identify_magic_bytes(raw)
                try:
                    decoded_str = raw.decode("utf-8")
                    return {"result": decoded_str, "is_binary": False, "magic": magic}
                except UnicodeDecodeError:
                    return {"result_hex": raw.hex(), "is_binary": True, "magic": magic}

            elif op == "hex":
                clean_hex = re.sub(r"[^0-9a-fA-F]", "", text)
                raw = bytes.fromhex(clean_hex)
                magic = cls.identify_magic_bytes(raw)
                try:
                    decoded_str = raw.decode("utf-8")
                    return {"result": decoded_str, "is_binary": False, "magic": magic}
                except UnicodeDecodeError:
                    return {"result_hex": raw.hex(), "is_binary": True, "magic": magic}

            elif op in ("url", "urldecode"):
                decoded_str = urllib.parse.unquote(text)
                return {"result": decoded_str, "is_binary": False}

            elif op == "rot13":
                decoded_str = codecs.decode(text, "rot_13")
                return {"result": decoded_str, "is_binary": False}

            elif op in ("zlib", "decompress"):
                # Handle hex or base64 wrapped compressed data
                try:
                    raw_in = bytes.fromhex(text.replace(" ", ""))
                except Exception:
                    raw_in = base64.b64decode(text)

                decompressor = zlib.decompressobj()
                decompressed = decompressor.decompress(raw_in, max_length=MAX_DECOMPRESSED_BYTES)
                if decompressor.unconsumed_tail:
                    return {"error": "Decompression bomb guard: output exceeds safe bound."}
                magic = cls.identify_magic_bytes(decompressed)
                try:
                    return {"result": decompressed.decode("utf-8"), "is_binary": False, "magic": magic}
                except UnicodeDecodeError:
                    return {"result_hex": decompressed.hex(), "is_binary": True, "magic": magic}

            else:
                return {"error": f"Unsupported decoding operation: {operation}"}

        except Exception as exc:
            return {"error": f"Decoding failed for {operation}: {exc}"}

    @classmethod
    def multi_layer_deobfuscate(cls, payload: str, max_depth: int = MAX_RECURSION_DEPTH) -> dict[str, Any]:
        """Automatically detect and peel layers of encoding (Base64, Hex, URL, ROT13)."""
        current = str(payload or "").strip()
        history: list[TransformationStep] = []
        depth = 0

        while depth < max_depth:
            depth += 1
            transformed = False

            # 1. URL encoded check (%20, %3D, etc.)
            if "%" in current and re.search(r"%[0-9a-fA-F]{2}", current):
                unquoted = urllib.parse.unquote(current)
                if unquoted != current:
                    current = unquoted
                    history.append(TransformationStep(depth, "urldecode", current[:120], len(current)))
                    transformed = True
                    continue

            # 2. Hex check (e.g. 48656c6c6f) - prefer hex if exclusively hex chars and even length
            clean_candidate = current.replace(" ", "").replace("0x", "")
            if len(clean_candidate) >= 8 and len(clean_candidate) % 2 == 0 and re.fullmatch(r"[0-9a-fA-F]+", clean_candidate):
                try:
                    raw_bytes = bytes.fromhex(clean_candidate)
                    decoded = raw_bytes.decode("utf-8")
                    if decoded.isprintable() and len(decoded) > 0 and decoded != current:
                        current = decoded
                        history.append(TransformationStep(depth, "hex_decode", current[:120], len(current)))
                        transformed = True
                        continue
                except Exception:
                    pass

            # 3. Base64 check
            b64_candidate = current.strip()
            if len(b64_candidate) >= 8 and len(b64_candidate) % 4 in (0, 2, 3) and re.fullmatch(r"[A-Za-z0-9+/=]+", b64_candidate):
                try:
                    pad = len(b64_candidate) % 4
                    if pad:
                        b64_candidate += "=" * (4 - pad)
                    raw_bytes = base64.b64decode(b64_candidate, validate=True)
                    decoded = raw_bytes.decode("utf-8")
                    if decoded.isprintable() and len(decoded) > 0 and decoded != current:
                        current = decoded
                        history.append(TransformationStep(depth, "base64_decode", current[:120], len(current)))
                        transformed = True
                        continue
                except Exception:
                    pass

            if not transformed:
                break

        return {
            "final_payload": current,
            "layers_peeled": len(history),
            "history": [
                {"layer": s.layer, "operation": s.operation, "preview": s.output_preview, "length": s.length}
                for s in history
            ],
        }

    @classmethod
    def compute_hash(cls, algorithm: str, data: str) -> dict[str, Any]:
        """Compute cryptographic digest: md5, sha1, sha256, sha512."""
        algo = algorithm.strip().lower()
        raw = data.encode("utf-8", errors="replace")
        try:
            if algo == "md5":
                return {"result": hashlib.md5(raw).hexdigest()}
            elif algo == "sha1":
                return {"result": hashlib.sha1(raw).hexdigest()}
            elif algo == "sha256":
                return {"result": hashlib.sha256(raw).hexdigest()}
            elif algo == "sha512":
                return {"result": hashlib.sha512(raw).hexdigest()}
            elif algo == "crc32":
                return {"result": hex(binascii.crc32(raw) & 0xFFFFFFFF)}
            else:
                return {"error": f"Unsupported hash algorithm: {algorithm}"}
        except Exception as exc:
            return {"error": str(exc)}

    @classmethod
    def analyze_network_log_or_pcap_header(cls, data: str | bytes) -> dict[str, Any]:
        """Parse lightweight network headers, web access logs, or pcap packet metadata.
        
        Extracts:
        - HTTP methods, response codes, URLs, IP addresses
        - Suspicious attack patterns (SQLi, path traversal, command injection, suspicious user-agents)
        """
        text = data if isinstance(data, str) else data.decode("utf-8", errors="replace")
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        
        ip_pattern = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")
        status_pattern = re.compile(r"\s(\d{3})\s")
        
        extracted_ips = set()
        status_codes = []
        suspicious_findings = []
        
        for line in lines[:500]:
            ips = ip_pattern.findall(line)
            for ip in ips:
                extracted_ips.add(ip)
            
            m_stat = status_pattern.search(line)
            if m_stat:
                status_codes.append(int(m_stat.group(1)))
                
            # Suspicious heuristics (check raw and url-decoded forms)
            decoded_line = urllib.parse.unquote_plus(line)
            lower = f"{line.lower()} {decoded_line.lower()}"
            if any(sqli in lower for sqli in ["' or '1'='1", "union select", "information_schema"]):
                suspicious_findings.append(f"SQL Injection indicator: {line[:80]}")
            if any(trav in lower for trav in ["../", "..\\", "/etc/passwd", "win.ini"]):
                suspicious_findings.append(f"Directory Traversal indicator: {line[:80]}")
            if any(cmd in lower for cmd in ["; cat ", "| whoami", "cmd.exe", "/bin/sh", "/bin/bash"]):
                suspicious_findings.append(f"Command Injection indicator: {line[:80]}")

        return {
            "total_lines_analyzed": len(lines),
            "unique_ips": sorted(list(extracted_ips)),
            "status_code_summary": {code: status_codes.count(code) for code in set(status_codes)},
            "suspicious_indicators": suspicious_findings[:10],
            "is_anomalous": len(suspicious_findings) > 0,
        }

    @classmethod
    def audit_code_vulnerabilities(cls, source_code: str, language: str = "python") -> dict[str, Any]:
        """Authorized static analysis of challenge-supplied source code for common CVE/CWE patterns.
        
        Checks for:
        - Insecure deserialization (pickle.loads, yaml.load)
        - Arbitrary execution (eval, exec, __import__, os.system, subprocess with shell=True)
        - Hardcoded credentials or tokens
        - Weak cryptography (DES, MD5 in security contexts)
        """
        findings = []
        lines = source_code.splitlines()
        
        dangerous_patterns = [
            (r"\bpickle\.loads\b", "CWE-502: Insecure Deserialization (pickle)"),
            (r"\byaml\.load\([^,)]+\)", "CWE-502: Unsafe YAML deserialization"),
            (r"\beval\s*\(", "CWE-95: Code Injection via eval()"),
            (r"\bexec\s*\(", "CWE-95: Code Injection via exec()"),
            (r"subprocess\.[A-Za-z]+\(.*shell\s*=\s*True", "CWE-78: Command Injection via shell=True"),
            (r"os\.system\s*\(", "CWE-78: OS Command Execution via os.system()"),
            (r"(?:api_key|password|secret|token)\s*=\s*['\"][A-Za-z0-9_\-]{8,}['\"]", "CWE-798: Hardcoded Credential/Secret"),
        ]
        
        for idx, line in enumerate(lines, 1):
            for pat, desc in dangerous_patterns:
                if re.search(pat, line, re.IGNORECASE):
                    findings.append({
                        "line": idx,
                        "vulnerability": desc,
                        "snippet": line.strip()[:100],
                    })

        return {
            "total_lines": len(lines),
            "vulnerabilities_detected": len(findings),
            "findings": findings[:15],
            "risk_level": "HIGH" if len(findings) > 0 else "LOW",
        }

    @classmethod
    def convert_timestamp(cls, timestamp: int | float) -> dict[str, Any]:
        """Convert Unix epoch timestamp to ISO 8601 UTC representation."""
        try:
            # Handle millisecond timestamps
            ts = float(timestamp)
            if ts > 1e11:
                ts /= 1000.0
            dt = datetime.datetime.fromtimestamp(ts, tz=datetime.timezone.utc)
            return {
                "iso": dt.isoformat(),
                "utc": dt.strftime("%Y-%m-%d %H:%M:%S UTC"),
                "year": dt.year,
                "month": dt.month,
                "day": dt.day,
            }
        except Exception as exc:
            return {"error": f"Timestamp conversion failed: {exc}"}

    @classmethod
    def parse_pcap_structure(cls, data: bytes | str) -> dict[str, Any]:
        """Offline parser for classic PCAP headers and frame records.
        
        Reads standard PCAP global header (24 bytes) and packet record headers (16 bytes each),
        parsing basic IP and TCP/UDP ports without external dependencies.
        """
        import struct

        if isinstance(data, str):
            clean = data.strip().replace(" ", "").replace("0x", "").replace("\n", "")
            try:
                raw = bytes.fromhex(clean)
            except Exception:
                raw = data.encode("utf-8", errors="replace")
        else:
            raw = data

        if len(raw) < 24:
            return {"error": "PCAP data too short (less than 24-byte global header)"}

        # Global header: magic (4B), version_maj (2B), min (2B), zone (4B), sigfigs (4B), snaplen (4B), network (4B)
        magic = raw[:4]
        if magic in (b"\xa1\xb2\xc3\xd4", b"\xd4\xc3\xb2\xa1"):
            endian = "<" if magic == b"\xd4\xc3\xb2\xa1" else ">"
        else:
            return {"error": f"Unrecognized PCAP magic header: {magic.hex()}"}

        try:
            ver_maj, ver_min, thiszone, sigfigs, snaplen, linktype = struct.unpack(
                f"{endian}HHIIII", raw[4:24]
            )
        except Exception as exc:
            return {"error": f"Failed to parse PCAP global header: {exc}"}

        offset = 24
        packets = []
        packet_idx = 0
        total_bytes = len(raw)

        while offset + 16 <= total_bytes and packet_idx < 50:
            packet_idx += 1
            ts_sec, ts_usec, incl_len, orig_len = struct.unpack(
                f"{endian}IIII", raw[offset : offset + 16]
            )
            offset += 16
            pkt_data = raw[offset : offset + incl_len]
            offset += incl_len

            # Parse Ethernet (14 bytes) -> IPv4 (20 bytes) if Ethernet linktype (1)
            pkt_info = {
                "packet_num": packet_idx,
                "timestamp": f"{ts_sec}.{ts_usec:06d}",
                "length": incl_len,
            }

            if linktype == 1 and len(pkt_data) >= 14:
                eth_type = struct.unpack("!H", pkt_data[12:14])[0]
                if eth_type == 0x0800 and len(pkt_data) >= 34:  # IPv4
                    ip_header = pkt_data[14:34]
                    proto = ip_header[9]
                    src_ip = ".".join(str(b) for b in ip_header[12:16])
                    dst_ip = ".".join(str(b) for b in ip_header[16:20])
                    pkt_info["src_ip"] = src_ip
                    pkt_info["dst_ip"] = dst_ip
                    pkt_info["protocol"] = "TCP" if proto == 6 else ("UDP" if proto == 17 else f"Proto-{proto}")

                    ihl = (ip_header[0] & 0x0F) * 4
                    l4_offset = 14 + ihl
                    if proto in (6, 17) and len(pkt_data) >= l4_offset + 4:
                        src_port, dst_port = struct.unpack("!HH", pkt_data[l4_offset : l4_offset + 4])
                        pkt_info["src_port"] = src_port
                        pkt_info["dst_port"] = dst_port

            packets.append(pkt_info)

        return {
            "endianness": "little" if endian == "<" else "big",
            "version": f"{ver_maj}.{ver_min}",
            "snaplen": snaplen,
            "linktype": linktype,
            "total_packets_parsed": len(packets),
            "packets": packets,
        }
