"""Evidence Ledger for BlackBox Explorer.

Records tool invocations, observations, discovered artifacts, and deduction history.
Designed for progressive expansion in Phase 3 (forensics).
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class EvidenceEntry:
    timestamp: float
    tool_name: str
    arguments: dict[str, Any]
    output_raw: str
    output_summary: str
    is_error: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)


class EvidenceLedger:
    """Thread-safe and async-safe ledger for storing investigative evidence."""

    def __init__(self, agent_id: str = "") -> None:
        self.agent_id = agent_id
        self.entries: list[EvidenceEntry] = []
        self.tools_called: set[str] = set()           # Genuinely successful tool invocations
        self.tools_attempted: set[str] = set()        # All tool invocations attempted
        self.tool_call_counts: dict[str, int] = {}
        self.call_signatures: set[str] = set()

    def record_call(
        self,
        tool_name: str,
        arguments: dict[str, Any],
        output: Any,
        is_error: bool = False,
    ) -> EvidenceEntry:
        """Record a completed tool call into the ledger."""
        now = time.time()
        self.tools_attempted.add(tool_name)
        if not is_error:
            self.tools_called.add(tool_name)
        self.tool_call_counts[tool_name] = self.tool_call_counts.get(tool_name, 0) + 1

        # Build stable signature for cycle detection
        sig = self._build_signature(tool_name, arguments)
        self.call_signatures.add(sig)

        # Sanitize and truncate output text
        rendered_output = self._render_output(output)
        summary = rendered_output[:250].replace("\n", " ").strip()
        if len(rendered_output) > 250:
            summary += "..."

        entry = EvidenceEntry(
            timestamp=now,
            tool_name=tool_name,
            arguments=arguments,
            output_raw=rendered_output,
            output_summary=summary,
            is_error=is_error,
        )
        self.entries.append(entry)
        return entry

    def is_repeated_call(self, tool_name: str, arguments: dict[str, Any]) -> bool:
        """Check if an identical call has already been made."""
        sig = self._build_signature(tool_name, arguments)
        return sig in self.call_signatures

    def get_summary_context(self, max_chars: int = 4000) -> str:
        """Format accumulated evidence into a readable markdown block for prompt context."""
        if not self.entries:
            return "No tool evidence gathered yet."

        blocks = []
        for i, entry in enumerate(self.entries, 1):
            status = "ERROR" if entry.is_error else "SUCCESS"
            # Limit individual raw outputs to keep prompt bounded
            content = entry.output_raw[:1200]
            if len(entry.output_raw) > 1200:
                content += "\n...[truncated]..."
            block = (
                f"### [Step {i}] Tool: `{entry.tool_name}` ({status})\n"
                f"- Input: `{json.dumps(entry.arguments, default=str)}`\n"
                f"- Output:\n```\n{content}\n```"
            )
            blocks.append(block)

        combined = "\n\n".join(blocks)
        if len(combined) > max_chars:
            return combined[-max_chars:]
        return combined

    def get_unique_tools_called(self) -> list[str]:
        return sorted(self.tools_called)

    @staticmethod
    def _build_signature(tool_name: str, arguments: dict[str, Any]) -> str:
        try:
            arg_str = json.dumps(arguments, sort_keys=True, default=str)
        except Exception:
            arg_str = str(sorted(arguments.items()))
        return f"{tool_name}:{arg_str}"

    @staticmethod
    def _render_output(output: Any) -> str:
        if output is None:
            return ""
        if isinstance(output, str):
            return output.strip()
        if isinstance(output, (dict, list)):
            try:
                return json.dumps(output, ensure_ascii=False, indent=2)
            except Exception:
                return str(output)
        return str(output)
