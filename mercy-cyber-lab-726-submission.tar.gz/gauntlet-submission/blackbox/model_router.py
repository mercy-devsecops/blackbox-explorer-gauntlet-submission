"""Dynamic Model Router for BlackBox Explorer.

Provides capability-aware model selection, benchmark/latency telemetry,
deadline-aware routing, and automatic fallback when models experience
rate limits, downtime, or tool-calling failures.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from base_strategy import ChallengeContext
from model_selector import (
    cached_model_rows,
    fetch_available_model_rows,
    prefer_image_models,
    require_explicit_model,
)

logger = logging.getLogger("blackbox.model_router")

# Capability profiles based on live Practice observations and benchmark tiers
MODEL_PROFILES: Dict[str, Dict[str, Any]] = {
    # High-speed models suitable for fast exploration, lightweight clues, and tight deadlines
    "nemotron-3.5-lightning": {
        "tier": "fast",
        "strengths": ["tool_use", "speed", "general_reasoning", "strict_format"],
        "token_cost_weight": 1.0,
        "native_tools": True,
        "is_vision": False,
    },
    "qwen3.7-flash": {
        "tier": "fast",
        "strengths": ["speed", "coding", "forensics", "tool_use"],
        "token_cost_weight": 1.0,
        "native_tools": True,
        "is_vision": False,
    },
    "gemini-3.6-flash": {
        "tier": "fast",
        "strengths": ["speed", "tool_use", "summarization"],
        "token_cost_weight": 1.1,
        "native_tools": True,
        "is_vision": False,
    },
    "gemini-3.8-flash": {
        "tier": "fast",
        "strengths": ["speed", "tool_use", "math"],
        "token_cost_weight": 1.2,
        "native_tools": True,
        "is_vision": False,
    },
    # Heavy reasoning models suitable for complex logic, multi-step math, and constraint deduction
    "nemotron-3-super": {
        "tier": "reasoning",
        "strengths": ["logic", "deduction", "math", "constraint_solving"],
        "token_cost_weight": 3.0,
        "native_tools": True,
        "is_vision": False,
    },
    "nemotron-3-ultra": {
        "tier": "heavy_reasoning",
        "strengths": ["complex_logic", "advanced_math", "synthesis"],
        "token_cost_weight": 5.0,
        "native_tools": True,
        "is_vision": False,
    },
    "qwen3.6-35b": {
        "tier": "reasoning",
        "strengths": ["coding", "logic", "deduction", "tool_use"],
        "token_cost_weight": 2.5,
        "native_tools": True,
        "is_vision": False,
    },
    "qwen3.7-plus": {
        "tier": "reasoning",
        "strengths": ["coding", "logic", "synthesis"],
        "token_cost_weight": 3.0,
        "native_tools": True,
        "is_vision": False,
    },
    "gpt-5.4": {
        "tier": "heavy_reasoning",
        "strengths": ["logic", "forensics", "creative_problem_solving"],
        "token_cost_weight": 6.0,
        "native_tools": True,
        "is_vision": False,
    },
}


@dataclass
class ModelMetrics:
    """Tracks latency, successful calls, and error counts per model."""
    success_count: int = 0
    failure_count: int = 0
    total_latency_ms: float = 0.0
    last_error: str = ""
    last_used: float = 0.0

    @property
    def avg_latency_ms(self) -> float:
        if self.success_count == 0:
            return 0.0
        return self.total_latency_ms / self.success_count


class ModelRouter:
    """Adaptive model router managing capability-based selection, health, and fallbacks."""

    def __init__(self, proxy_host: Optional[str] = None, api_key: str = ""):
        self.proxy_host = proxy_host
        self.api_key = api_key
        self.metrics: Dict[str, ModelMetrics] = {}
        self._cached_roster: List[str] = []
        self._cached_rows: List[Dict[str, Any]] = []
        self._last_discovery_time: float = 0.0
        self.discovery_ttl_s: float = 300.0  # Avoid repeated discovery requests within 5 minutes

    def discover_roster(self, force: bool = False) -> List[str]:
        """Discover live models with caching to prevent excessive discovery queries."""
        now = time.monotonic()
        if not force and self._cached_roster and (now - self._last_discovery_time < self.discovery_ttl_s):
            return list(self._cached_roster)

        rows = fetch_available_model_rows(self.proxy_host, self.api_key)
        if not rows:
            rows = cached_model_rows()

        self._cached_rows = rows
        self._cached_roster = [str(r.get("id")).strip() for r in rows if str(r.get("id")).strip()]
        self._last_discovery_time = now

        for model in self._cached_roster:
            if model not in self.metrics:
                self.metrics[model] = ModelMetrics()

        return list(self._cached_roster)

    def record_outcome(self, model: str, latency_ms: float, success: bool, error: str = ""):
        """Record model execution metrics for informed routing decisions."""
        if model not in self.metrics:
            self.metrics[model] = ModelMetrics()
        m = self.metrics[model]
        m.last_used = time.monotonic()
        if success:
            m.success_count += 1
            m.total_latency_ms += latency_ms
        else:
            m.failure_count += 1
            m.last_error = error

    def select_model(
        self,
        context: ChallengeContext,
        available_models: Optional[List[str]] = None,
        task_type: str = "solve",
        remaining_time_s: Optional[float] = None,
    ) -> str:
        """Capability-aware model selection matching challenge requirements and deadline budget.
        
        Routing Policies:
        1. Image challenges -> Vision-capable models via prefer_image_models.
        2. Tight deadline (< 30s) or fast exploration -> High-speed/low-latency models (nemotron-3.5-lightning, qwen3.7-flash).
        3. Heavy logic / math with comfortable deadline (> 45s) -> High-reasoning models (nemotron-3-super, qwen3.6-35b, gpt-5.4).
        4. Tool-intensive investigation -> Models with proven robust native tool calling.
        5. Degraded/Failing models -> Automatically deprioritized or bypassed.
        """
        roster = available_models or self.discover_roster()
        if not roster:
            return ""

        # Image challenge handling
        if context.challenge_type == "image" or context.image_url:
            ranked_image = prefer_image_models(roster, model_rows=self._cached_rows)
            for m in ranked_image:
                if self.is_healthy(m):
                    return m
            return ranked_image[0] if ranked_image else roster[0]

        # Determine task intent and deadline pressure
        desc = (context.description or "").lower()
        rules = (context.rules or "").lower()
        is_complex_logic = any(k in desc or k in rules for k in ["chronological", "logic", "puzzle", "deduce", "order", "arrange"])
        is_math = any(k in desc or k in rules for k in ["calculate", "math", "prime", "modulo", "equation", "formula", "combinatorics"])
        is_coding_forensics = any(k in desc or k in rules for k in ["hash", "base64", "decode", "binary", "hex", "pcap", "script", "algorithm"])
        
        time_left = remaining_time_s if remaining_time_s is not None else getattr(context, "time_remaining_s", None)
        time_is_critical = (time_left is not None and time_left < 30.0)

        # Build candidate preferences
        preferred_candidates: List[str] = []

        if time_is_critical:
            # Under time pressure, prioritize fast models with low latency and native tool reliability
            preferred_candidates = ["nemotron-3.5-lightning", "qwen3.7-flash", "gemini-3.6-flash", "gemini-3.8-flash"]
        elif is_complex_logic or is_math:
            # Complex reasoning tasks with ample time benefit from deep reasoning architectures
            preferred_candidates = [
                "nemotron-3.5-lightning",  # Validated 100 quality on practice_logic_hard_001
                "nemotron-3-super",
                "qwen3.6-35b",
                "qwen3.7-plus",
                "gpt-5.4",
                "qwen3.7-flash",
            ]
        elif is_coding_forensics:
            # Coding and forensic challenges
            preferred_candidates = ["qwen3.7-flash", "qwen3.6-35b", "nemotron-3.5-lightning", "gemini-3.8-flash"]
        else:
            # General investigation / tool-heavy tasks
            preferred_candidates = ["nemotron-3.5-lightning", "qwen3.7-flash", "gemini-3.6-flash", "qwen3.6-35b"]

        # Filter by actual availability and health
        for cand in preferred_candidates:
            if cand in roster and self.is_healthy(cand):
                return cand

        # Fallback to any healthy model in roster
        for m in roster:
            if self.is_healthy(m):
                return m

        # Last-ditch: first model in roster
        return roster[0]

    def get_fallback_model(self, failed_model: str, available_models: List[str]) -> str:
        """Return the best alternative healthy model when a model fails."""
        self.record_outcome(failed_model, latency_ms=0, success=False, error="Fallback triggered")
        for m in available_models:
            if m != failed_model and self.is_healthy(m):
                logger.info(f"Failing over from {failed_model} to healthy fallback: {m}")
                return m
        # If all healthy checks exhausted, pick any different model
        for m in available_models:
            if m != failed_model:
                return m
        return failed_model

    def is_healthy(self, model: str) -> bool:
        """Model health check: bypass if consecutive recent failures exceed threshold."""
        m = self.metrics.get(model)
        if not m:
            return True
        if m.failure_count >= 3 and m.success_count == 0:
            return False
        if m.failure_count > m.success_count * 2 and m.failure_count >= 4:
            return False
        return True
