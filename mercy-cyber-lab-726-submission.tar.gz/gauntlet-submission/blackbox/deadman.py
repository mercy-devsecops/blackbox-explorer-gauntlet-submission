"""Deadline management, submission controller, and idempotency protection.

Features:
- Accurate monotonic countdown calculation from organizer challenge max_time_s.
- Dynamic submission safety margins (never blocks early turns, reserves measured submission budget).
- Best candidate answer preservation (prioritizes validated candidates over raw guesses).
- Automatic draft saving as a safety net (drafts do NOT finalize submissions).
- Idempotent final submission with exact retry on network failure (avoids 409 Conflict).
- Concurrency protection: enforces single-submission execution.
- Image MCP submission pathway preservation with REST fallback.
"""

from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass
from typing import Any, Callable

from arena_clients import ArenaAPIError, ArenaConnectionError, HttpArenaClient, McpArenaClient, SubmitResult
from blackbox.validator import AnswerValidator, ValidationResult

logger = logging.getLogger("blackbox.deadman")

# Measured time needed to transmit HTTP/MCP final answer payload
DEFAULT_SAFETY_MARGIN_S = 6.0


@dataclass
class CandidateRecord:
    answer: str
    is_validated: bool
    format_type: str
    timestamp: float
    source: str


class DeadlineController:
    """Manages challenge clock, candidate tracking, draft backups, and submission idempotency."""

    def __init__(
        self,
        agent_id: str,
        max_time_s: int,
        http_client: HttpArenaClient | None = None,
        mcp_client: McpArenaClient | None = None,
        safety_margin_s: float = DEFAULT_SAFETY_MARGIN_S,
        is_image: bool = False,
    ) -> None:
        self.agent_id = agent_id
        self.max_time_s = max(10, int(max_time_s or 60))
        self.http_client = http_client
        self.mcp_client = mcp_client
        self.safety_margin_s = max(2.0, float(safety_margin_s))
        self.is_image = is_image

        self.start_monotonic = time.monotonic()
        self.deadline_monotonic = self.start_monotonic + self.max_time_s

        self.best_candidate: CandidateRecord | None = None
        self.last_saved_draft: str = ""
        self.final_submitted_answer: str | None = None
        self.final_receipt: Any = None
        self.is_submitted: bool = False
        self._lock = asyncio.Lock()

    def time_remaining(self) -> float:
        """Seconds remaining until the challenge deadline expires."""
        return max(0.0, self.deadline_monotonic - time.monotonic())

    def should_continue_investigation(self, estimated_call_cost_s: float = 6.0) -> bool:
        """Determines if enough time remains to begin another reasoning or tool turn."""
        remaining = self.time_remaining()
        required_buffer = self.safety_margin_s + estimated_call_cost_s
        return remaining > required_buffer

    def register_candidate(
        self,
        raw_answer: str,
        rules: str = "",
        source: str = "solver",
    ) -> ValidationResult:
        """Inspect and register a new candidate answer.
        
        Prioritizes validated candidates over raw guesses.
        """
        validation = AnswerValidator.validate(raw_answer, rules)
        now = time.monotonic()

        record = CandidateRecord(
            answer=validation.cleaned_answer if validation.is_valid else raw_answer,
            is_validated=validation.is_valid,
            format_type=validation.format_detected,
            timestamp=now,
            source=source,
        )

        # Update best candidate if:
        # 1. No candidate yet
        # 2. New candidate is valid while old was invalid
        # 3. Both valid or both invalid, take the newer one
        if self.best_candidate is None:
            self.best_candidate = record
        elif record.is_validated and not self.best_candidate.is_validated:
            self.best_candidate = record
        elif record.is_validated == self.best_candidate.is_validated:
            self.best_candidate = record

        # Automatically save an intermediate draft via REST if supported
        if self.http_client and not self.is_image and validation.is_valid:
            self.save_draft_safe(record.answer, f"Draft candidate from {source}")

        return validation

    def save_draft_safe(self, draft_text: str, rationale: str = "") -> bool:
        """Save intermediate answer draft to server (does NOT finalize submission)."""
        clean_text = str(draft_text or "").strip()
        if not clean_text or clean_text == self.last_saved_draft or not self.http_client:
            return False
        try:
            self.http_client.save_draft(self.agent_id, clean_text, rationale)
            self.last_saved_draft = clean_text
            return True
        except Exception as e:
            logger.debug(f"Save draft notice: {e}")
            return False

    async def submit_final(
        self,
        answer: str | None = None,
        client_metrics: dict[str, Any] | None = None,
        challenge_type: str = "text",
    ) -> SubmitResult | dict[str, Any]:
        """Execute final submission with exact retry idempotency and concurrency locking.
        
        Rules Enforced:
        - Submission is official and immutable.
        - Concurrent calls return the existing receipt.
        - On ambiguous failure, retry the EXACT SAME answer to recover the canonical receipt.
        - A conflicting second answer is strictly blocked to avoid HTTP 409.
        """
        async with self._lock:
            # 1. Idempotency Check: Already submitted?
            if self.is_submitted and self.final_receipt is not None:
                return self.final_receipt

            # 2. Select best answer to submit
            chosen_answer = ""
            if answer and str(answer).strip():
                chosen_answer = str(answer).strip()
            elif self.best_candidate and self.best_candidate.answer:
                chosen_answer = self.best_candidate.answer
            elif self.last_saved_draft:
                chosen_answer = self.last_saved_draft
            else:
                chosen_answer = "unknown"

            # Check for conflict protection if we attempted an answer previously
            if self.final_submitted_answer is not None and chosen_answer != self.final_submitted_answer:
                logger.warning(
                    f"Blocked conflicting answer attempt '{chosen_answer}'! "
                    f"Must retry exact original answer '{self.final_submitted_answer}'."
                )
                chosen_answer = self.final_submitted_answer

            self.final_submitted_answer = chosen_answer
            metrics = dict(client_metrics or {})

            # 3. Image Pathway vs Text Pathway
            if self.is_image:
                receipt = await self._submit_image_with_retry(chosen_answer, metrics)
            else:
                receipt = await self._submit_text_with_retry(chosen_answer, metrics, challenge_type)

            self.final_receipt = receipt
            self.is_submitted = True
            return receipt

    async def _submit_text_with_retry(
        self,
        answer: str,
        metrics: dict[str, Any],
        challenge_type: str,
    ) -> SubmitResult:
        """Submit text answer to REST API with exact-retry idempotency."""
        if not self.http_client:
            raise RuntimeError("HttpArenaClient is required for text submission.")

        # Attempt 1: Direct submission
        try:
            res = await asyncio.to_thread(
                self.http_client.submit,
                agent_id=self.agent_id,
                answer=answer,
                client_metrics=metrics,
                challenge_type=challenge_type,
            )
            return res
        except ArenaAPIError as exc:
            # If 409 conflict, another call or previous attempt already landed; retrieve session receipt
            if exc.status_code == 409:
                logger.warning(f"Submission returned 409 Conflict. Checking session for official receipt...")
                try:
                    session = await asyncio.to_thread(self.http_client.get_session, self.agent_id)
                    return SubmitResult(
                        accepted=session.get("accepted", True),
                        agent_id=self.agent_id,
                        answer=session.get("final_answer", answer),
                        score=session.get("score"),
                        status="submitted",
                    )
                except Exception:
                    pass
            raise
        except (ArenaConnectionError, Exception) as exc:
            # Network blip or timeout: Retry exact same answer once to recover receipt
            logger.warning(f"Submission encountered network issue ({exc}). Retrying exact same answer for canonical receipt...")
            await asyncio.sleep(1.0)
            res = await asyncio.to_thread(
                self.http_client.submit,
                agent_id=self.agent_id,
                answer=answer,
                client_metrics=metrics,
                challenge_type=challenge_type,
            )
            return res

    async def _submit_image_with_retry(
        self,
        image_uri: str,
        metrics: dict[str, Any],
    ) -> dict[str, Any] | SubmitResult:
        """Submit image answer via MCP tool with fallback to REST."""
        # 1. Prefer McpArenaClient.submit_image
        if self.mcp_client:
            try:
                res = await self.mcp_client.submit_image(
                    agent_id=self.agent_id,
                    image_uri=image_uri,
                    client_metrics=metrics,
                    rationale="blackbox deadline controller submission",
                )
                return res
            except Exception as mcp_err:
                logger.warning(f"MCP image submission failed ({mcp_err}); falling back to REST submission pathway.")

        # 2. Permitted Fallback: REST API submit
        if self.http_client:
            return await asyncio.to_thread(
                self.http_client.submit,
                agent_id=self.agent_id,
                answer=image_uri,
                client_metrics=metrics,
                challenge_type="image",
            )

        raise RuntimeError("No available transport to submit image challenge.")
