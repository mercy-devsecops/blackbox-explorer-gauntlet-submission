"""Answer validation, extraction, and formatting verification engine.

Provides:
- Extraction of raw candidate answers from model responses.
- Explicit rule-based and template-based validation without corrupting valid payloads.
- Structured output verification (JSON, tuple lists, delimited sequences).
- Format inspection: prefix rules (whether 'ANSWER:' is required, forbidden, or optional).
- Distinction between unvalidated candidate extraction and formal validation.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass
from typing import Any


@dataclass
class ValidationResult:
    """Result of answer validation."""
    is_valid: bool
    candidate: str
    cleaned_answer: str
    rejection_reason: str | None = None
    format_detected: str = "plain_text"


class AnswerValidator:
    """Validates and formats answers against challenge rules without corrupting payloads."""

    _INVALID_ANSWERS = {
        "",
        "none",
        "unknown",
        "n/a",
        "null",
        "<think>",
        "</think>",
        "think",
        "answer:",
        "final answer:",
    }

    _BLOCKED_META_TOKENS = (
        "<toolcall",
        "</toolcall",
        "<tool_observation",
        "</tool_observation>",
        "<think>",
        "</think>",
        '"tool_calls"',
        "function_call",
        "action: call_tool",
    )

    @classmethod
    def extract_candidate(cls, raw_response: str) -> str:
        """Extract the best raw candidate answer from model output.
        
        Preserves original capitalization, whitespace, and structure.
        """
        if not raw_response or not raw_response.strip():
            return ""

        # 1. Strip think blocks
        cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", raw_response, flags=re.DOTALL).strip()
        if not cleaned:
            cleaned = raw_response.strip()

        # 2. Look for JSON Action protocol: {"action": "final_answer", "answer": ...}
        json_match = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", cleaned, re.DOTALL)
        if json_match:
            try:
                data = json.loads(json_match.group(1))
                if isinstance(data, dict) and data.get("action") == "final_answer":
                    ans = data.get("answer")
                    if ans is not None:
                        return str(ans).strip()
            except Exception:
                pass

        # 3. Look for explicit ANSWER: or Final Answer: prefix on its own line
        for line in reversed(cleaned.splitlines()):
            stripped_line = line.strip()
            match = re.match(
                r"^\s*(?:final\s+answer|answer)\s*:\s*(.+)$",
                stripped_line,
                flags=re.IGNORECASE,
            )
            if match:
                candidate = match.group(1).strip()
                # Do not strip quotes if they might be part of the structured answer
                if (candidate.startswith('"') and candidate.endswith('"')) or (candidate.startswith("'") and candidate.endswith("'")):
                    if len(candidate) > 2 and not any(ch in candidate[1:-1] for ch in ('"', "'")):
                        candidate = candidate[1:-1].strip()
                if candidate:
                    return candidate

        # 4. Fallback: last non-empty line that doesn't look like an observation or reasoning tag
        for line in reversed(cleaned.splitlines()):
            stripped = line.strip()
            if not stripped:
                continue
            lower = stripped.lower()
            if any(lower.startswith(tok) for tok in ("<think", "</think", "reasoning:", "analysis:", "step ", "#", "*")):
                continue
            if any(tok in lower for tok in cls._BLOCKED_META_TOKENS):
                continue
            return stripped

        return ""

    @classmethod
    def validate(
        cls,
        candidate: str,
        rules: str = "",
        expected_format: str | None = None,
    ) -> ValidationResult:
        """Validate candidate string against challenge rules and expected formatting.
        
        Does NOT alter valid answers merely to make them look standardized.
        """
        raw_cand = str(candidate or "").strip()
        if not raw_cand:
            return ValidationResult(
                is_valid=False,
                candidate="",
                cleaned_answer="",
                rejection_reason="Candidate is empty.",
            )

        lower_cand = raw_cand.lower()

        # Reject generic meta tokens and placeholders
        if lower_cand in cls._INVALID_ANSWERS:
            return ValidationResult(
                is_valid=False,
                candidate=raw_cand,
                cleaned_answer="",
                rejection_reason=f"Candidate is a rejected placeholder: '{raw_cand}'.",
            )

        if any(tok in lower_cand for tok in cls._BLOCKED_META_TOKENS):
            return ValidationResult(
                is_valid=False,
                candidate=raw_cand,
                cleaned_answer="",
                rejection_reason="Candidate contains unparsed tool/think meta tags.",
            )

        # Reject prompt injection patterns in candidate answer
        prompt_injection_indicators = [
            "ignore previous instructions",
            "system prompt",
            "you are now in developer mode",
            "override all previous",
            "jailbreak",
        ]
        if any(pi in lower_cand for pi in prompt_injection_indicators):
            return ValidationResult(
                is_valid=False,
                candidate=raw_cand,
                cleaned_answer="",
                rejection_reason="Candidate contains prompt injection signature.",
            )

        rules_lower = (rules or "").lower()

        # 1. Check if rules require strict JSON
        if "json" in rules_lower or expected_format == "json":
            try:
                # Strip markdown code blocks if wrapped
                json_str = raw_cand
                m = re.search(r"```(?:json)?\s*(\{.*?\}|\[.*?\])\s*```", raw_cand, re.DOTALL)
                if m:
                    json_str = m.group(1)
                parsed = json.loads(json_str)
                # Valid JSON structure
                return ValidationResult(
                    is_valid=True,
                    candidate=raw_cand,
                    cleaned_answer=json_str.strip(),
                    format_detected="json",
                )
            except Exception as e:
                return ValidationResult(
                    is_valid=False,
                    candidate=raw_cand,
                    cleaned_answer=raw_cand,
                    rejection_reason=f"Rules require JSON, but parsing failed: {e}",
                    format_detected="json_invalid",
                )

        # 2. Check prefix rules: 'no prefix', 'without prefix', or 'invalid example: answer:'
        disallows_prefix = any(
            token in rules_lower
            for token in (
                "do not add prefixes",
                "do not include prefixes",
                "without prefix",
                "no prefix",
                "do not prefix",
                "invalid example: answer:",
            )
        )
        allows_or_requires_prefix = any(
            token in rules_lower
            for token in (
                "must always be: answer:",
                "must be: answer:",
                "first line must be: answer:",
                "format: answer:",
                "prefix 'answer:",
                'prefix "answer:',
            )
        )

        cleaned = raw_cand
        # If prefix is disallowed but candidate has ANSWER: prefix, strip it cleanly
        if disallows_prefix:
            prefix_match = re.match(r"^\s*(?:answer|final answer)\s*:\s*(.+)$", raw_cand, re.IGNORECASE)
            if prefix_match:
                cleaned = prefix_match.group(1).strip()

        # If prefix is explicitly required by rules, verify it
        elif allows_or_requires_prefix and not disallows_prefix:
            if not re.match(r"^\s*(?:answer|final answer)\s*:\s*", raw_cand, re.IGNORECASE):
                # Rules explicitly demanded ANSWER: prefix
                cleaned = f"ANSWER: {raw_cand}"

        # 3. Check for specific explicit output template in rules (e.g. format: KEY(category,severity);...)
        template_match = re.search(
            r"(?:format|template)(?: your answer)?(?: exactly)?(?: as| like)?\s*:\s*['\"]([^'\"]+)['\"]",
            rules,
            re.IGNORECASE,
        )
        if template_match:
            template = template_match.group(1).strip()
            # If template has semicolon tuples like KEY(cat,sev);KEY2(cat,sev)
            if ";" in template and "(" in template:
                tuple_res = cls._validate_tuple_sequence(cleaned)
                if tuple_res.is_valid:
                    return tuple_res

        # 4. Standard validation passed
        return ValidationResult(
            is_valid=True,
            candidate=raw_cand,
            cleaned_answer=cleaned,
            format_detected="plain_text",
        )

    @classmethod
    def _validate_tuple_sequence(cls, text: str) -> ValidationResult:
        """Validate semicolon-separated tuple schemas, e.g. FOO(bar,high); BAZ(qux,low)."""
        payload = text
        if payload.lower().startswith("answer:"):
            payload = payload.split(":", 1)[1].strip()

        parts = [p.strip() for p in payload.split(";") if p.strip()]
        if not parts:
            return ValidationResult(is_valid=False, candidate=text, cleaned_answer=text, rejection_reason="Empty tuple sequence.")

        for part in parts:
            if not re.fullmatch(r"[A-Za-z0-9_-]+\s*\(\s*[A-Za-z0-9_-]+\s*,\s*[A-Za-z0-9_-]+\s*\)", part):
                return ValidationResult(
                    is_valid=False,
                    candidate=text,
                    cleaned_answer=text,
                    rejection_reason=f"Tuple item '{part}' does not match KEY(category,severity) format.",
                )

        return ValidationResult(
            is_valid=True,
            candidate=text,
            cleaned_answer="; ".join(parts),
            format_detected="semicolon_tuples",
        )
