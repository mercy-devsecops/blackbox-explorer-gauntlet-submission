"""Multimodal Image Engine for BlackBox Explorer.

Provides robust, deadline-aware image generation, image editing,
optional closed-loop visual critique (via image_analyze), and safe candidate preservation.
"""

from __future__ import annotations

import logging
import time
from typing import Any, Dict, Optional, Tuple

from arena_clients import McpArenaClient, build_image_tool_arguments
from blackbox.deadman import DeadlineController
from blackbox.telemetry import TelemetryManager

logger = logging.getLogger("blackbox.image_engine")

BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)


class ImageEngine:
    """Handles image pipeline operations, verification, and candidate management."""

    def __init__(
        self,
        mcp_client: McpArenaClient,
        deadman: DeadlineController,
        telemetry: TelemetryManager,
        agent_id: str,
    ):
        self.mcp_client = mcp_client
        self.deadman = deadman
        self.telemetry = telemetry
        self.agent_id = agent_id

    async def execute_image_task(
        self,
        tool_defs: list[dict[str, Any]],
        tools: set[str],
        selected_model: str,
        prompt_text: str,
        input_image_uri: Optional[str] = None,
        llm_api_key: str = "",
        arena_api_key: str = "",
        enable_critique: bool = True,
    ) -> Tuple[str, Dict[str, Any]]:
        """Executes image generation or editing with optional single-turn verification."""
        is_edit = bool(input_image_uri) and ("image_edit" in tools)
        tool_name = "image_edit" if is_edit else "image_generate"

        proxy_args = build_image_tool_arguments(
            tool_defs,
            tool_name,
            selected_model=selected_model,
            llm_api_key=llm_api_key,
            arena_api_key=arena_api_key,
        )

        self.telemetry.broadcast_thought(f"Executing {tool_name} with {selected_model}...")
        primary_args: Dict[str, Any] = {
            "prompt": prompt_text,
            "agent_id": self.agent_id,
            **proxy_args,
        }
        if is_edit:
            primary_args["image_uri"] = input_image_uri

        start_time = time.monotonic()
        try:
            res = await self.mcp_client.call_tool(tool_name, primary_args)
            candidate_uri = str(res.get("image_uri") or "").strip()
        except Exception as e:
            logger.error(f"Image tool {tool_name} failed: {e}")
            self.telemetry.broadcast_thought(f"Primary image generation encountered: {e}")
            candidate_uri = ""

        # Candidate fallback if tool returned empty or failed
        if not candidate_uri:
            candidate_uri = input_image_uri or BLANK_PNG_DATA_URI

        # Register best available candidate into deadman controller immediately
        self.deadman.register_candidate(
            raw_answer=candidate_uri,
            rules="image_payload",
            source=tool_name,
        )

        details: Dict[str, Any] = {
            "tool_called": tool_name,
            "model_used": selected_model,
            "latency_ms": int((time.monotonic() - start_time) * 1000),
            "critique_performed": False,
            "corrective_retry": False,
        }

        # For image edits, preserve the high-scoring baseline approach:
        # Avoid unneeded post-generation critique on standard image-edit tasks,
        # which can degrade quality through style drift or introduce extra latency.
        if is_edit:
            return candidate_uri, details

        # Check conditions for closed-loop critique (primarily for generation from scratch):
        remaining_s = self.deadman.time_remaining()
        can_critique = (
            enable_critique
            and "image_analyze" in tools
            and candidate_uri
            and candidate_uri != BLANK_PNG_DATA_URI
            and remaining_s > 50.0
        )

        if not can_critique:
            return candidate_uri, details

        # Perform conditional visual critique
        try:
            self.telemetry.broadcast_thought("Analyzing generated image against task prompt...")
            analyze_args = build_image_tool_arguments(
                tool_defs,
                "image_analyze",
                selected_model=selected_model,
                llm_api_key=llm_api_key,
                arena_api_key=arena_api_key,
            )
            critique_res = await self.mcp_client.call_tool("image_analyze", {
                "image_uri": candidate_uri,
                "prompt": f"Verify if this image satisfies: '{prompt_text}'. Point out missing elements or defects.",
                "agent_id": self.agent_id,
                **analyze_args,
            })
            analysis_text = str(critique_res.get("analysis") or critique_res.get("description") or "").strip()
            details["critique_performed"] = True
            details["analysis"] = analysis_text

            # If serious defects are flagged and ample time remains (> 35s), attempt at most 1 corrective retry
            defect_keywords = ["missing", "incorrect", "defect", "fails", "incomplete", "blurry", "wrong"]
            has_defect = any(k in analysis_text.lower() for k in defect_keywords)
            time_permits_retry = self.deadman.time_remaining() > 35.0

            if has_defect and time_permits_retry:
                self.telemetry.broadcast_thought("Critique identified potential issue. Attempting single corrective refinement...")
                refined_prompt = f"{prompt_text}. Note: ensure {analysis_text[:120]}"
                retry_args = dict(primary_args)
                retry_args["prompt"] = refined_prompt
                
                retry_res = await self.mcp_client.call_tool(tool_name, retry_args)
                retry_uri = str(retry_res.get("image_uri") or "").strip()
                if retry_uri:
                    candidate_uri = retry_uri
                    details["corrective_retry"] = True
                    self.deadman.register_candidate(
                        raw_answer=candidate_uri,
                        rules="image_payload",
                        source=f"{tool_name}_corrective_retry",
                    )
        except Exception as e:
            logger.warning(f"Optional image critique encountered non-fatal error: {e}")

        return candidate_uri, details

    async def analyze_diagram_or_visual_logic(
        self,
        tool_defs: list[dict[str, Any]],
        tools: set[str],
        selected_model: str,
        image_uri: str,
        question_or_task: str,
        llm_api_key: str = "",
        arena_api_key: str = "",
    ) -> Dict[str, Any]:
        """Structured 6-step visual reasoning pipeline for charts, diagrams, and OCR evidence.
        
        Steps:
        1. Overview / Scene identification.
        2. Text / OCR extraction.
        3. Node / entity identification.
        4. Relational / directed flow mapping.
        5. Specific question answering.
        6. Confidence assessment.
        """
        if "image_analyze" not in tools:
            return {"error": "image_analyze tool not available in discovered tools"}

        analyze_args = build_image_tool_arguments(
            tool_defs,
            "image_analyze",
            selected_model=selected_model,
            llm_api_key=llm_api_key,
            arena_api_key=arena_api_key,
        )

        structured_prompt = (
            f"Analyze this diagram/image systematically to answer: '{question_or_task}'.\n"
            "Follow these 6 structured visual reasoning steps:\n"
            "1. Overview: Identify type of diagram (flowchart, network diagram, chart, table, screenshot).\n"
            "2. Text/Labels: Transcribe all visible text labels, headers, numbers, and identifiers accurately.\n"
            "3. Entities/Components: List key nodes, boxes, systems, or data points.\n"
            "4. Relationships: Trace connections, arrows, directions, dependencies, or axes.\n"
            "5. Direct Answer: Formulate the exact answer to the target question.\n"
            "6. Confidence: State confidence and note any ambiguous or occluded details."
        )

        self.telemetry.broadcast_thought("Executing 6-step visual reasoning analysis on diagram...")
        try:
            res = await self.mcp_client.call_tool("image_analyze", {
                "image_uri": image_uri,
                "prompt": structured_prompt,
                "agent_id": self.agent_id,
                **analyze_args,
            })
            analysis = str(res.get("analysis") or res.get("description") or res).strip()
            return {
                "success": True,
                "analysis": analysis,
                "model_used": selected_model,
            }
        except Exception as exc:
            logger.warning(f"Diagram visual reasoning failed: {exc}")
            return {
                "success": False,
                "error": str(exc),
            }
