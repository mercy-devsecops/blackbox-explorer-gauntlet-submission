"""Evidence Provenance and Competing Hypotheses Tracker for BlackBox Explorer.

Extends EvidenceLedger with:
- Source identification, origin, sequence, and reliability indicators.
- Hypothesis generation, evidence support / contradiction tracking.
- Inconsistency detection among clues.
- Deterministic hypothesis scoring.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set


@dataclass
class Hypothesis:
    hypothesis_id: str
    description: str
    supporting_evidence_ids: List[int] = field(default_factory=list)
    contradicting_evidence_ids: List[int] = field(default_factory=list)
    confidence_score: float = 0.5  # 0.0 to 1.0
    rationale: str = ""


@dataclass
class ProvenanceRecord:
    evidence_id: int
    source_type: str  # e.g., 'mcp_tool', 'local_deterministic', 'challenge_clue', 'user_rule'
    origin_name: str  # tool name or clue source
    sequence_num: int
    timestamp: float
    reliability: float = 1.0  # 1.0 = verified/deterministic, 0.8 = LLM inference, 0.5 = untrusted artifact
    is_tainted: bool = False   # True if retrieved from untrusted/external source subject to injection
    data_summary: str = ""


class HypothesisEngine:
    """Bounded, fast competing hypothesis tracker and evidence correlation mechanism."""

    def __init__(self) -> None:
        self.hypotheses: Dict[str, Hypothesis] = {}
        self.provenance_records: List[ProvenanceRecord] = []
        self._next_evidence_id: int = 1

    def add_provenance(
        self,
        source_type: str,
        origin_name: str,
        data_summary: str,
        reliability: float = 1.0,
        is_tainted: bool = False,
    ) -> int:
        """Register evidence provenance with integrity metadata."""
        ev_id = self._next_evidence_id
        self._next_evidence_id += 1
        rec = ProvenanceRecord(
            evidence_id=ev_id,
            source_type=source_type,
            origin_name=origin_name,
            sequence_num=len(self.provenance_records) + 1,
            timestamp=time.time(),
            reliability=reliability,
            is_tainted=is_tainted,
            data_summary=data_summary[:200],
        )
        self.provenance_records.append(rec)
        return ev_id

    def register_hypothesis(
        self,
        hypothesis_id: str,
        description: str,
        rationale: str = "",
    ) -> Hypothesis:
        """Register a candidate hypothesis for competing evaluation."""
        hypo = Hypothesis(
            hypothesis_id=hypothesis_id,
            description=description,
            rationale=rationale,
        )
        self.hypotheses[hypothesis_id] = hypo
        return hypo

    def evaluate_evidence_against_hypotheses(
        self,
        evidence_id: int,
        supports: List[str],
        contradicts: List[str],
    ) -> None:
        """Link an evidence item to supporting and contradicting hypotheses."""
        for hid in supports:
            if hid in self.hypotheses:
                if evidence_id not in self.hypotheses[hid].supporting_evidence_ids:
                    self.hypotheses[hid].supporting_evidence_ids.append(evidence_id)
        for hid in contradicts:
            if hid in self.hypotheses:
                if evidence_id not in self.hypotheses[hid].contradicting_evidence_ids:
                    self.hypotheses[hid].contradicting_evidence_ids.append(evidence_id)

    def rank_hypotheses(self) -> List[Dict[str, Any]]:
        """Rank hypotheses deterministically based on net weighted evidence."""
        prov_map = {p.evidence_id: p for p in self.provenance_records}
        ranked = []
        for hid, h in self.hypotheses.items():
            support_weight = sum(prov_map[eid].reliability for eid in h.supporting_evidence_ids if eid in prov_map)
            contra_weight = sum(prov_map[eid].reliability for eid in h.contradicting_evidence_ids if eid in prov_map)
            net_score = support_weight - (contra_weight * 1.5)  # Contradictions penalize heavily
            
            # Bound confidence between 0.05 and 0.99
            total = support_weight + contra_weight
            confidence = max(0.05, min(0.99, (support_weight + 1.0) / (total + 2.0)))
            if contra_weight > 0 and support_weight == 0:
                confidence = 0.05

            ranked.append({
                "hypothesis_id": hid,
                "description": h.description,
                "net_score": round(net_score, 2),
                "confidence": round(confidence, 2),
                "support_count": len(h.supporting_evidence_ids),
                "contradiction_count": len(h.contradicting_evidence_ids),
                "is_viable": contra_weight == 0 or support_weight > contra_weight,
            })

        ranked.sort(key=lambda x: (x["is_viable"], x["net_score"], x["confidence"]), reverse=True)
        return ranked

    def get_best_hypothesis(self) -> Tuple[Optional[str], Optional[Hypothesis]]:
        """Return the top-ranked hypothesis ID and instance."""
        ranked = self.rank_hypotheses()
        if not ranked:
            return None, None
        top_id = ranked[0]["hypothesis_id"]
        return top_id, self.hypotheses.get(top_id)

    def detect_inconsistencies(self, clues: List[str]) -> List[str]:
        """Detect obvious direct contradictions in textual clues deterministically."""
        inconsistencies = []
        lower_clues = [c.lower() for c in clues if c.strip()]
        for i, c1 in enumerate(lower_clues):
            for c2 in lower_clues[i + 1:]:
                # Check for direct pairwise contradictions (e.g. A before B vs B before A)
                if "before" in c1 and "before" in c2:
                    # Look for mirrored pair patterns
                    words1 = c1.replace(".", "").split()
                    words2 = c2.replace(".", "").split()
                    if len(words1) >= 3 and len(words2) >= 3:
                        if words1[0] == words2[-1] and words1[-1] == words2[0]:
                            inconsistencies.append(f"Direct ordering conflict between: '{clues[i]}' and '{clues[lower_clues.index(c2)]}'")
        return inconsistencies
