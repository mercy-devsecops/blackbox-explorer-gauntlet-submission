"""Deterministic mathematical and computational engine for BlackBox Explorer.

Provides:
- AST-validated safe arithmetic (no unrestricted eval/exec).
- High-precision decimal and fractions.
- Modular arithmetic (mod, mod_pow, mod_inverse).
- Combinatorics (permutations, combinations, factorials).
- Number theory (gcd, lcm, is_prime, prime_factors).
- Safe constraint satisfaction and bounded permutation search.
"""

from __future__ import annotations

import ast
import math
import operator
from fractions import Fraction
from typing import Any

MAX_SAFE_INT_DIGITS = 4096
MAX_FACTORIAL_N = 1000
MAX_PERMUTATION_ITEMS = 10


class ComputationSecurityError(ValueError):
    """Raised when an expression attempts unsafe operations."""


class SafeMathEvaluator(ast.NodeVisitor):
    """Evaluates mathematical expressions using AST white-listing (no eval/exec)."""

    _ALLOWED_OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.FloorDiv: operator.floordiv,
        ast.Mod: operator.mod,
        ast.Pow: operator.pow,
        ast.USub: operator.neg,
        ast.UAdd: operator.pos,
    }

    _ALLOWED_FUNCTIONS = {
        "abs": abs,
        "round": round,
        "min": min,
        "max": max,
        "sqrt": math.isqrt,
        "gcd": math.gcd,
        "lcm": math.lcm,
    }

    def visit(self, node: ast.AST) -> Any:
        return super().visit(node)

    def visit_Expression(self, node: ast.Expression) -> Any:
        return self.visit(node.body)

    def visit_Constant(self, node: ast.Constant) -> Any:
        if isinstance(node.value, (int, float)):
            return node.value
        raise ComputationSecurityError(f"Disallowed constant type: {type(node.value).__name__}")

    def visit_UnaryOp(self, node: ast.UnaryOp) -> Any:
        op_type = type(node.op)
        if op_type not in self._ALLOWED_OPERATORS:
            raise ComputationSecurityError(f"Unsupported unary operator: {op_type.__name__}")
        val = self.visit(node.operand)
        return self._ALLOWED_OPERATORS[op_type](val)

    def visit_BinOp(self, node: ast.BinOp) -> Any:
        op_type = type(node.op)
        if op_type not in self._ALLOWED_OPERATORS:
            raise ComputationSecurityError(f"Unsupported binary operator: {op_type.__name__}")
        left = self.visit(node.left)
        right = self.visit(node.right)

        # Guard against power explosion (e.g. 9999 ** 9999)
        if op_type is ast.Pow:
            if isinstance(right, (int, float)) and right > 10000:
                raise ComputationSecurityError(f"Exponent {right} exceeds safe evaluation limit (10000).")

        return self._ALLOWED_OPERATORS[op_type](left, right)

    def visit_Call(self, node: ast.Call) -> Any:
        if not isinstance(node.func, ast.Name):
            raise ComputationSecurityError("Dynamic function calls are forbidden.")
        func_name = node.func.id
        if func_name not in self._ALLOWED_FUNCTIONS:
            raise ComputationSecurityError(f"Function '{func_name}' is not in allowlist.")
        args = [self.visit(arg) for arg in node.args]
        return self._ALLOWED_FUNCTIONS[func_name](*args)

    def generic_visit(self, node: ast.AST) -> Any:
        raise ComputationSecurityError(f"Unsupported expression syntax: {type(node).__name__}")


class ComputationEngine:
    """Deterministic mathematical and constraint solving suite."""

    @classmethod
    def evaluate_expression(cls, expr: str) -> dict[str, Any]:
        """Safely parse and evaluate an arithmetic expression."""
        clean = str(expr or "").strip()
        if not clean:
            return {"error": "Empty expression"}
        if len(clean) > 500:
            return {"error": "Expression exceeds max length (500 chars)"}

        try:
            tree = ast.parse(clean, mode="eval")
            evaluator = SafeMathEvaluator()
            result = evaluator.visit(tree)
            return {"result": str(result), "numeric": result}
        except ZeroDivisionError:
            return {"error": "Division by zero"}
        except ComputationSecurityError as sec_err:
            return {"error": f"Security restriction: {sec_err}"}
        except Exception as exc:
            return {"error": f"Evaluation error: {exc}"}

    @classmethod
    def modular_arithmetic(
        cls,
        operation: str,
        base: int,
        modulus: int,
        exponent: int | None = None,
    ) -> dict[str, Any]:
        """Perform modular operations: mod, pow_mod, or inverse_mod."""
        if modulus <= 0:
            return {"error": "Modulus must be a positive integer."}

        op = operation.strip().lower()
        try:
            if op == "mod":
                return {"result": base % modulus}
            elif op == "pow_mod":
                if exponent is None:
                    return {"error": "Exponent required for pow_mod."}
                return {"result": pow(base, exponent, modulus)}
            elif op == "inverse_mod":
                try:
                    return {"result": pow(base, -1, modulus)}
                except ValueError:
                    return {"error": f"{base} has no modular inverse modulo {modulus}."}
            else:
                return {"error": f"Unknown modular operation: {operation}"}
        except Exception as exc:
            return {"error": str(exc)}

    @classmethod
    def combinatorics(
        cls,
        operation: str,
        n: int,
        k: int | None = None,
    ) -> dict[str, Any]:
        """Calculate factorial, combinations (n choose k), or permutations."""
        if n < 0 or (k is not None and k < 0):
            return {"error": "n and k must be non-negative integers."}
        if n > MAX_FACTORIAL_N:
            return {"error": f"n exceeds max safe bound ({MAX_FACTORIAL_N})."}

        op = operation.strip().lower()
        try:
            if op == "factorial":
                return {"result": math.factorial(n)}
            elif op in ("combinations", "choose"):
                if k is None or k > n:
                    return {"error": "k must satisfy 0 <= k <= n for combinations."}
                return {"result": math.comb(n, k)}
            elif op == "permutations":
                if k is None or k > n:
                    return {"error": "k must satisfy 0 <= k <= n for permutations."}
                return {"result": math.perm(n, k)}
            else:
                return {"error": f"Unknown combinatorics operation: {operation}"}
        except Exception as exc:
            return {"error": str(exc)}

    @classmethod
    def number_theory(cls, operation: str, numbers: list[int]) -> dict[str, Any]:
        """Number theory operations: gcd, lcm, is_prime, prime_factors."""
        if not numbers:
            return {"error": "Numbers list cannot be empty."}

        op = operation.strip().lower()
        try:
            if op == "gcd":
                res = numbers[0]
                for x in numbers[1:]:
                    res = math.gcd(res, x)
                return {"result": res}
            elif op == "lcm":
                res = numbers[0]
                for x in numbers[1:]:
                    res = math.lcm(res, x)
                return {"result": res}
            elif op == "is_prime":
                num = numbers[0]
                if num <= 1:
                    return {"result": False}
                if num <= 3:
                    return {"result": True}
                if num % 2 == 0 or num % 3 == 0:
                    return {"result": False}
                i = 5
                while i * i <= num:
                    if num % i == 0 or num % (i + 2) == 0:
                        return {"result": False}
                    i += 6
                return {"result": True}
            elif op == "prime_factors":
                num = numbers[0]
                if num <= 1:
                    return {"result": []}
                factors = []
                d = 2
                while d * d <= num:
                    while num % d == 0:
                        factors.append(d)
                        num //= d
                    d += 1
                if num > 1:
                    factors.append(num)
                return {"result": factors}
            else:
                return {"error": f"Unknown number theory operation: {operation}"}
        except Exception as exc:
            return {"error": str(exc)}

    @classmethod
    def solve_linear_order_constraints(
        cls,
        items: list[str],
        constraints: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Deterministic constraint solver for permutation & sequence ordering puzzles.
        
        Constraints supported:
        - {"type": "before", "item_a": "X", "item_b": "Y"} -> X comes before Y
        - {"type": "immediately_before", "item_a": "X", "item_b": "Y"} -> index(X) + 1 == index(Y)
        - {"type": "immediately_after", "item_a": "X", "item_b": "Y"} -> index(X) - 1 == index(Y)
        - {"type": "not_at_index", "item": "X", "indices": [0, 1]} -> index(X) not in indices
        - {"type": "at_index", "item": "X", "index": 4} -> index(X) == 4
        """
        import itertools
        if len(items) > MAX_PERMUTATION_ITEMS:
            return {"error": f"Item count {len(items)} exceeds max deterministic search limit ({MAX_PERMUTATION_ITEMS})."}

        valid_permutations = []
        for perm in itertools.permutations(items):
            idx_map = {item: i for i, item in enumerate(perm)}
            sat = True
            for c in constraints:
                c_type = c.get("type")
                if c_type == "before":
                    a, b = c.get("item_a"), c.get("item_b")
                    if a in idx_map and b in idx_map and idx_map[a] >= idx_map[b]:
                        sat = False
                        break
                elif c_type == "immediately_before":
                    a, b = c.get("item_a"), c.get("item_b")
                    if a in idx_map and b in idx_map and idx_map[a] + 1 != idx_map[b]:
                        sat = False
                        break
                elif c_type == "immediately_after":
                    a, b = c.get("item_a"), c.get("item_b")
                    if a in idx_map and b in idx_map and idx_map[a] - 1 != idx_map[b]:
                        sat = False
                        break
                elif c_type == "not_at_index":
                    item = c.get("item")
                    indices = c.get("indices", [])
                    if item in idx_map and idx_map[item] in indices:
                        sat = False
                        break
                elif c_type == "at_index":
                    item = c.get("item")
                    target_idx = c.get("index")
                    if item in idx_map and idx_map[item] != target_idx:
                        sat = False
                        break
            if sat:
                valid_permutations.append(list(perm))
                if len(valid_permutations) > 10:
                    break  # Multiple solutions

        if not valid_permutations:
            return {"status": "unsatisfiable", "solution": None}
        elif len(valid_permutations) == 1:
            return {
                "status": "unique_solution",
                "solution": valid_permutations[0],
                "solution_str": ", ".join(valid_permutations[0]),
            }
        else:
            return {
                "status": "multiple_solutions",
                "count": len(valid_permutations),
                "solutions": valid_permutations[:5],
            }

    @classmethod
    def fraction_arithmetic(cls, numerator: int, denominator: int) -> dict[str, Any]:
        """Reduce fractions and compute high-precision representation."""
        if denominator == 0:
            return {"error": "Denominator cannot be zero."}
        try:
            frac = Fraction(numerator, denominator)
            return {
                "reduced": f"{frac.numerator}/{frac.denominator}",
                "numerator": frac.numerator,
                "denominator": frac.denominator,
                "decimal": float(frac),
            }
        except Exception as exc:
            return {"error": str(exc)}
