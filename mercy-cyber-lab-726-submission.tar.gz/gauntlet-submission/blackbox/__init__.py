"""BlackBox Explorer core modules."""

from .recon import ReconManager, mcp_to_openai_tool, validate_tool_arguments
from .ledger import EvidenceLedger, EvidenceEntry
from .telemetry import TelemetryManager
from .investigator import InvestigatorEngine
from .validator import AnswerValidator, ValidationResult
from .deadman import DeadlineController, CandidateRecord
from .computation import ComputationEngine
from .forensics import ForensicsEngine
from .local_tools import LOCAL_TOOL_DEFINITIONS
from .model_router import ModelRouter
from .image_engine import ImageEngine
from .hypotheses import HypothesisEngine, ProvenanceRecord, Hypothesis
from .classifier import DynamicClassifier, ChallengeProfile, SolutionPipeline

__all__ = [
    "ReconManager",
    "mcp_to_openai_tool",
    "validate_tool_arguments",
    "EvidenceLedger",
    "EvidenceEntry",
    "TelemetryManager",
    "InvestigatorEngine",
    "AnswerValidator",
    "ValidationResult",
    "DeadlineController",
    "CandidateRecord",
    "ComputationEngine",
    "ForensicsEngine",
    "LOCAL_TOOL_DEFINITIONS",
    "ModelRouter",
    "ImageEngine",
    "HypothesisEngine",
    "ProvenanceRecord",
    "Hypothesis",
    "DynamicClassifier",
    "ChallengeProfile",
    "SolutionPipeline",
]
