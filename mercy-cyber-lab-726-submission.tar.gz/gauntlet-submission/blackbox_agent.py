#!/usr/bin/env python3
"""BlackBox Explorer: Competition-grade autonomous agent entrypoint.

Integrates:
- REST Registration & Session Monitoring.
- MCP Server connection & dynamic tool discovery.
- Local deterministic utilities (math, logic, forensics) via ReconManager.
- Autonomous ReAct investigation loop.
- Answer validation & output formatting.
- Monotonic deadline control with safe draft saving and idempotent submit.
- Preserved working baseline image-challenge pathway.
- Attribution telemetry and run record generation.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from dotenv import load_dotenv
load_dotenv(REPO_ROOT / ".env")

from openai import OpenAI

from arena_clients.config import agent_id_problem
from arena_clients import (
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    build_image_tool_arguments,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.display import print_challenge, challenge_record, save_run_record
from arena_clients.outputs import missing_tools_note, save_submitted_image, submission_summary_lines
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from model_selector import fetch_available_models, require_explicit_model
from my_strategy import MyStrategy

from blackbox import (
    ReconManager,
    InvestigatorEngine,
    TelemetryManager,
    DeadlineController,
    AnswerValidator,
    ModelRouter,
    ImageEngine,
    DynamicClassifier,
    SolutionPipeline,
    HypothesisEngine,
)
from blackbox.local_tools import LOCAL_TOOL_DEFINITIONS

BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)


async def main():
    strategy = MyStrategy()
    agent_id = (os.getenv("AGENT_ID") or getattr(strategy, "agent_id", "") or "mercy-cyber-lab-726").strip()
    agent_name = (os.getenv("AGENT_NAME") or getattr(strategy, "agent_name", "") or "BlackBox Explorer").strip()
    os.environ["AGENT_ID"] = agent_id
    os.environ["AGENT_NAME"] = agent_name

    id_err = agent_id_problem(agent_id)
    if id_err:
        raise SystemExit(f"❌ {id_err}")

    print(f"🤖 BlackBox Explorer starting...")
    print(f"   Agent ID: {agent_id} | Name: {agent_name}")

    ensure_connected()

    api_base = get_api_base()
    mcp_url = get_mcp_url()
    llm_host = get_proxy_host()
    api_key = get_arena_api_key()
    llm_api_key = api_key

    # Initialize REST Client & Register
    http_client = HttpArenaClient(api_base=api_base, api_key=api_key)
    print("📝 Registering with Agent Gauntlet...")
    session = http_client.register(agent_id, agent_name)
    print(f"   Session ID: {session.session_id} (Status: {session.status})")
    session_monitor = monitor_session(http_client, agent_id).start()

    async with McpArenaClient(mcp_url) as mcp_client:
        tools = await mcp_client.list_tools()
        tool_defs = await mcp_client.list_tool_defs()
        modality = McpArenaClient.detect_modality(tools, agent_id=agent_id)

        usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope

        available_models = fetch_available_models(llm_host, llm_api_key)
        telemetry = TelemetryManager(
            http_client=http_client,
            mcp_client=mcp_client,
            agent_id=agent_id,
            usage_scope=usage_scope,
            is_image=(modality == "image"),
        )

        # =================================================================
        # BRANCH A: IMAGE CHALLENGE PATHWAY (Preserved Baseline)
        # =================================================================
        if modality == "image":
            print("\n🎨 Handling Image Challenge via Preserved Baseline Pathway...")
            while True:
                try:
                    challenge = await mcp_client.get_image_challenge(agent_id)
                    break
                except McpArenaError as e:
                    if "locked" in str(e).lower() or "waiting for organizer" in str(e).lower():
                        print("   Waiting for organizer to start battle...")
                        await asyncio.sleep(3.0)
                    else:
                        raise

            print_challenge(challenge)
            deadman = DeadlineController(
                agent_id=agent_id,
                max_time_s=challenge.max_time_s,
                http_client=http_client,
                mcp_client=mcp_client,
                is_image=True,
            )

            # Pick image model
            from base_strategy import ChallengeContext
            img_ctx = ChallengeContext(
                challenge_type=challenge.challenge_type,
                challenge_text=challenge.description,
                description=challenge.description,
                rules=challenge.prompt or "",
                max_time_s=challenge.max_time_s,
                available_models=available_models,
                image_url=challenge.input_image_uri,
            )
            ranked_models = strategy.rank_models(img_ctx, available_models)
            model_name = strategy.pick_model("solve", ranked_models, img_ctx)
            model_name = require_explicit_model(model_name, available_models, source="BlackBox image pipeline")

            telemetry.broadcast_thought(f"Selected image model: {model_name}")
            # Ensure thought is broadcast over MCP channel before image generation
            await telemetry.broadcast_thought_async(f"Generating image with {model_name}")
            prompt_text = strategy.build_image_prompt(img_ctx)

            image_engine = ImageEngine(
                mcp_client=mcp_client,
                deadman=deadman,
                telemetry=telemetry,
                agent_id=agent_id,
            )
            output_image_uri, img_details = await image_engine.execute_image_task(
                tool_defs=tool_defs,
                tools=tools,
                selected_model=model_name,
                prompt_text=prompt_text,
                input_image_uri=challenge.input_image_uri,
                llm_api_key=llm_api_key,
                arena_api_key=api_key,
                enable_critique=True,
            )

            telemetry.broadcast_thought("Submitting final image answer...")
            submit_res = await deadman.submit_final(
                answer=output_image_uri,
                client_metrics={"model_name": model_name, "total_time_ms": int((time.monotonic() - deadman.start_monotonic) * 1000)},
            )
            await session_monitor.stop()

            for line in submission_summary_lines(submit_res):
                print(f"   {line}")
            print(f"   Image saved: {save_submitted_image(agent_id, output_image_uri, REPO_ROOT)}")
            print("✅ BlackBox Explorer completed successfully.")
            return

        # =================================================================
        # BRANCH B: TEXT / INVESTIGATIVE / GENERAL-PURPOSE CHALLENGE
        # =================================================================
        print("\n🔍 Handling Challenge via Autonomous ReAct Investigation Engine...")
        while True:
            try:
                challenge = await mcp_client.get_challenge(agent_id)
                break
            except McpArenaError as e:
                if "locked" in str(e).lower() or "waiting for organizer" in str(e).lower():
                    print("   Waiting for organizer to start battle...")
                    await asyncio.sleep(3.0)
                else:
                    raise

        print_challenge(challenge)
        deadman = DeadlineController(
            agent_id=agent_id,
            max_time_s=challenge.max_time_s,
            http_client=http_client,
            mcp_client=mcp_client,
            is_image=False,
        )

        # Adaptive Model Router
        model_router = ModelRouter(proxy_host=llm_host, api_key=llm_api_key)
        from base_strategy import ChallengeContext
        txt_ctx = ChallengeContext(
            challenge_type=challenge.challenge_type,
            description=challenge.description,
            rules=challenge.rules,
            max_time_s=challenge.max_time_s,
            available_models=available_models,
            time_remaining_s=deadman.time_remaining(),
        )
        # Capability-aware selection with fallback to strategy ranking
        model_name = model_router.select_model(
            context=txt_ctx,
            available_models=available_models,
            task_type="solve",
            remaining_time_s=deadman.time_remaining(),
        )
        if not model_name:
            ranked = strategy.rank_models(txt_ctx, available_models)
            model_name = strategy.pick_model("solve", ranked, txt_ctx)
        model_name = require_explicit_model(model_name, available_models, source="BlackBox text solver")

        headers = build_proxy_headers(agent_id=agent_id, usage_scope=usage_scope)
        llm_client = OpenAI(base_url=llm_host, api_key=llm_api_key, default_headers=headers)

        # Read clues
        clue_ids = await mcp_client.list_clues(agent_id)
        clues = []
        for c_id in clue_ids:
            clue = await mcp_client.get_clue(c_id, agent_id)
            clues.append(clue.text)
        if not clues and challenge.clues:
            clues = [str(c) for c in challenge.clues]

        telemetry.broadcast_thought(f"Loaded {len(clues)} clues. Discovering capabilities...")

        # Setup Reconnaissance: Combine MCP tools + Local Deterministic Tools
        all_tool_defs = list(tool_defs) + LOCAL_TOOL_DEFINITIONS
        recon_manager = ReconManager(all_tool_defs)

        # Record genuine intake tools that were successfully called
        investigator = InvestigatorEngine(
            llm_client=llm_client,
            model_name=model_name,
            recon_manager=recon_manager,
            mcp_client=mcp_client,
            telemetry_manager=telemetry,
            agent_id=agent_id,
            cached_clues={c_id: clue_text for c_id, clue_text in zip(clue_ids, clues)} if clue_ids and clues else {f"clue_{i+1}": c for i, c in enumerate(clues)},
            cached_challenge={"description": challenge.description, "rules": challenge.rules, "clues": clues} if challenge else {},
        )
        # Record only tools that genuinely succeeded during intake
        if challenge is not None and "arena.get_challenge" in tools:
            investigator.ledger.record_call("arena.get_challenge", {"agent_id": agent_id}, {"success": True}, is_error=False)
        if bool(clue_ids) and "arena.clues.list" in tools:
            investigator.ledger.record_call("arena.clues.list", {"agent_id": agent_id}, {"clue_ids": clue_ids}, is_error=False)
        if bool(clues) and "arena.clues.get" in tools:
            investigator.ledger.record_call("arena.clues.get", {"agent_id": agent_id, "clue_id": clue_ids[0] if clue_ids else "clue_0"}, {"text": clues[0]}, is_error=False)

        required_tools = challenge.raw_data.get("required_tools", [])
        telemetry.broadcast_thought(f"Investigating with {model_name}...")

        # Autonomous Solve Loop
        solve_result = await investigator.solve_challenge(
            challenge_description=challenge.description,
            challenge_rules=challenge.rules,
            clues=clues,
            required_tools=required_tools,
            deadline_remaining_s=deadman.time_remaining(),
        )

        # Dynamic Classification & Pipeline Verification (Phase 7)
        classifier = DynamicClassifier()
        profile = classifier.classify(
            task_text=challenge.description,
            clues=[{"text": c} for c in clues],
            available_tools=list(tools),
        )
        telemetry.broadcast_thought(f"Challenge classified: {profile.primary_category} (fmt={profile.expected_output_format})")
        pipeline = SolutionPipeline(profile)
        is_valid_fmt, v_reason, formatted_ans = pipeline.verify_answer(
            candidate_answer=solve_result["answer"],
            retrieved_evidence=clues,
        )
        candidate_to_validate = formatted_ans if (is_valid_fmt and formatted_ans) else solve_result["answer"]

        # Validate candidate answer
        validation = deadman.register_candidate(
            raw_answer=candidate_to_validate,
            rules=challenge.rules,
            source="InvestigatorEngine",
        )

        telemetry.broadcast_thought(f"Validated answer. Preparing final submission...")
        telemetry.ensure_minimum_thoughts()

        # Final Submission
        final_answer = validation.cleaned_answer or candidate_to_validate or "unknown"
        submit_res = await deadman.submit_final(
            answer=final_answer,
            client_metrics={
                "model_name": model_name,
                "total_time_ms": int((time.monotonic() - deadman.start_monotonic) * 1000),
            },
            challenge_type=challenge.challenge_type or "text",
        )
        await session_monitor.stop()

        print("\n📤 Submission Result:")
        print(f"   Accepted: {submit_res.accepted}")
        print(f"   Status: {submit_res.status}")
        if submit_res.score:
            print(f"   Final Score: {submit_res.score.get('final_score', 0)}")
            print(f"   Quality: {submit_res.score.get('quality_score', 0)}")
            print(f"   Speed: {submit_res.score.get('speed_score', 0)}")
        if missing_tools_note(submit_res):
            print(f"   ⚠️  {missing_tools_note(submit_res)}")

        # Save run record
        run_record = {
            "agent_id": agent_id,
            "challenge": challenge_record(challenge),
            "model": model_name,
            "answer": final_answer,
            "solve_details": solve_result,
            "result": {
                "accepted": submit_res.accepted,
                "status": submit_res.status,
                "score": submit_res.score,
            },
        }
        print(f"   Run record saved: {save_run_record(agent_id, run_record, REPO_ROOT)}")
        print("✅ BlackBox Explorer completed successfully.")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)
